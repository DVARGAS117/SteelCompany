-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 27-03-2022 a las 09:12:18
-- Versión del servidor: 5.7.23-23
-- Versión de PHP: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `abelito_xxNeo2030`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accesos_usuarios`
--

CREATE TABLE `accesos_usuarios` (
  `cod_acceso` int(11) NOT NULL,
  `cod_personal` int(11) DEFAULT NULL,
  `cod_modulo` int(11) DEFAULT NULL,
  `cod_submodulo` int(11) DEFAULT NULL,
  `modulo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insertar` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editar` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eliminar` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consultar` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `accesos_usuarios`
--

INSERT INTO `accesos_usuarios` (`cod_acceso`, `cod_personal`, `cod_modulo`, `cod_submodulo`, `modulo`, `insertar`, `editar`, `eliminar`, `consultar`) VALUES
(1, 6, 1, 1, 'Datos de Empresa', 'SI', 'SI', 'SI', 'SI'),
(2, 6, 1, 2, 'Tiendas/Locales', 'SI', 'SI', 'SI', 'SI'),
(3, 6, 1, 3, 'Personal', 'SI', 'SI', 'SI', 'SI'),
(4, 6, 2, 4, 'Apertura Caja', 'SI', 'SI', 'SI', 'SI'),
(5, 6, 2, 5, 'Crear Boletas/Facturas', 'SI', 'SI', 'SI', 'SI'),
(6, 6, 2, 6, 'Crear Notas de Crédito', 'SI', 'SI', 'SI', 'SI'),
(7, 6, 2, 7, 'Guias de Remisión', 'SI', 'SI', 'SI', 'SI'),
(8, 6, 2, 8, 'Lista de Ventas', 'SI', 'SI', 'SI', 'SI'),
(9, 6, 3, 9, 'Facturas Electrónicas', 'SI', 'SI', 'SI', 'SI'),
(10, 6, 3, 10, 'Boletas Electrónicas', 'SI', 'SI', 'SI', 'SI'),
(11, 6, 3, 11, 'Resumen de Boletas', 'SI', 'SI', 'SI', 'SI'),
(12, 6, 3, 12, 'Enviar Guías de Remisión', 'SI', 'SI', 'SI', 'SI'),
(13, 6, 3, 13, 'Reporte para Sunat', 'SI', 'SI', 'SI', 'SI'),
(14, 6, 4, 14, 'Categorias', 'SI', 'SI', 'SI', 'SI'),
(15, 6, 4, 15, 'Marcas', 'SI', 'SI', 'SI', 'SI'),
(16, 6, 4, 16, 'Productos', 'SI', 'SI', 'SI', 'SI'),
(17, 6, 5, 17, 'Ingreso Productos', 'SI', 'SI', 'SI', 'SI'),
(18, 6, 5, 18, 'Salida Productos', 'SI', 'SI', 'SI', 'SI'),
(19, 6, 5, 19, 'Devoluciones', 'SI', 'SI', 'SI', 'SI'),
(20, 6, 6, 20, 'Modulos de Sistema', 'SI', 'SI', 'SI', 'SI'),
(21, 6, 6, 21, 'Tipos de Documento', 'SI', 'SI', 'SI', 'SI'),
(22, 6, 6, 22, 'Tipo Nota Credito', 'SI', 'SI', 'SI', 'SI'),
(23, 6, 6, 23, 'Series de Documento', 'SI', 'SI', 'SI', 'SI'),
(24, 6, 6, 24, 'Clientes', 'SI', 'SI', 'SI', 'SI'),
(25, 6, 6, 25, 'Cargos', 'SI', 'SI', 'SI', 'SI'),
(26, 6, 7, 26, 'Reportes Generales', 'SI', 'SI', 'SI', 'SI'),
(27, 6, 8, 27, 'Exportar Base de Datos', 'SI', 'SI', 'SI', 'SI'),
(28, 6, 8, 28, 'Exportar Para Concat', 'SI', 'SI', 'SI', 'SI'),
(29, 6, 8, 29, 'Exportar Syscont', 'SI', 'SI', 'SI', 'SI'),
(41, 1, 1, 3, 'Personal', 'SI', 'SI', 'SI', 'SI'),
(40, 1, 1, 2, 'Tiendas/Locales', 'SI', 'SI', 'SI', 'SI'),
(39, 1, 1, 1, 'Datos de Empresa', 'SI', 'SI', 'SI', 'SI'),
(104, 7, 6, 24, 'Clientes', 'SI', 'SI', 'SI', 'SI'),
(103, 7, 2, 5, 'Crear Boletas/Facturas', 'SI', 'SI', 'SI', 'SI'),
(42, 1, 2, 4, 'Apertura Caja', 'SI', 'SI', 'SI', 'SI'),
(43, 1, 2, 5, 'Crear Boletas/Facturas', 'SI', 'SI', 'SI', 'SI'),
(44, 1, 2, 6, 'Crear Notas de Crédito', 'SI', 'SI', 'SI', 'SI'),
(45, 1, 2, 7, 'Guias de Remisión', 'SI', 'SI', 'SI', 'SI'),
(46, 1, 2, 8, 'Lista de Ventas', 'SI', 'SI', 'SI', 'SI'),
(47, 1, 3, 9, 'Facturas Electrónicas', 'SI', 'SI', 'SI', 'SI'),
(48, 1, 3, 10, 'Boletas Electrónicas', 'SI', 'SI', 'SI', 'SI'),
(49, 1, 3, 11, 'Resumen de Boletas', 'SI', 'SI', 'SI', 'SI'),
(50, 1, 3, 12, 'Enviar Guías de Remisión', 'SI', 'SI', 'SI', 'SI'),
(51, 1, 3, 13, 'Reporte para Sunat', 'SI', 'SI', 'SI', 'SI'),
(52, 1, 4, 14, 'Categorias', 'SI', 'SI', 'SI', 'SI'),
(53, 1, 4, 15, 'Marcas', 'SI', 'SI', 'SI', 'SI'),
(54, 1, 4, 16, 'Productos', 'SI', 'SI', 'SI', 'SI'),
(55, 1, 5, 17, 'Ingreso Productos', 'SI', 'SI', 'SI', 'SI'),
(56, 1, 5, 18, 'Salida Productos', 'SI', 'SI', 'SI', 'SI'),
(57, 1, 5, 19, 'Devoluciones', 'SI', 'SI', 'SI', 'SI'),
(58, 1, 6, 20, 'Modulos de Sistema', 'SI', 'SI', 'SI', 'SI'),
(59, 1, 6, 21, 'Tipos de Documento', 'SI', 'SI', 'SI', 'SI'),
(60, 1, 6, 22, 'Tipo Nota Credito', 'SI', 'SI', 'SI', 'SI'),
(61, 1, 6, 23, 'Series de Documento', 'SI', 'SI', 'SI', 'SI'),
(62, 1, 6, 24, 'Clientes', 'SI', 'SI', 'SI', 'SI'),
(63, 1, 6, 25, 'Cargos', 'SI', 'SI', 'SI', 'SI'),
(64, 1, 7, 26, 'Reportes Generales', 'SI', 'SI', 'SI', 'SI'),
(65, 1, 8, 27, 'Exportar Base de Datos', 'SI', 'SI', 'SI', 'SI'),
(66, 1, 8, 28, 'Exportar Para Concat', 'SI', 'SI', 'SI', 'SI'),
(67, 1, 8, 29, 'Exportar Syscont', 'SI', 'SI', 'SI', 'SI'),
(101, 7, 2, 7, 'Guias de Remisión', 'SI', 'SI', 'SI', 'SI'),
(102, 7, 2, 4, 'Apertura Caja', 'SI', 'SI', 'SI', 'SI'),
(99, 7, 5, 19, 'Devoluciones', 'SI', 'SI', 'SI', 'SI'),
(100, 7, 2, 6, 'Crear Notas de Crédito', 'SI', 'SI', 'SI', 'SI'),
(98, 7, 4, 16, 'Productos', 'SI', 'SI', 'SI', 'SI'),
(97, 7, 2, 8, 'Lista de Ventas', 'SI', 'SI', 'SI', 'SI'),
(224, 5, 6, 24, 'Clientes', 'SI', 'SI', 'SI', 'SI'),
(223, 5, 5, 19, 'Devoluciones', 'SI', 'SI', 'SI', 'SI'),
(222, 5, 2, 4, 'Apertura Caja', 'SI', 'SI', 'SI', 'SI'),
(221, 5, 4, 16, 'Productos', 'SI', 'SI', 'SI', 'SI'),
(220, 5, 2, 7, 'Guias de Remisión', 'SI', 'SI', 'SI', 'SI'),
(219, 5, 2, 8, 'Lista de Ventas', 'SI', 'SI', 'SI', 'SI'),
(218, 5, 2, 5, 'Crear Boletas/Facturas', 'SI', 'SI', 'SI', 'SI'),
(217, 5, 2, 6, 'Crear Notas de Crédito', 'SI', 'SI', 'SI', 'SI');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `apertura_cajas`
--

CREATE TABLE `apertura_cajas` (
  `cod_apertura` int(11) NOT NULL,
  `fecha_creacion` date DEFAULT NULL,
  `fecha_apertura` timestamp NULL DEFAULT NULL,
  `fecha_cierre` timestamp NULL DEFAULT NULL,
  `nombre_caja` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `turno` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cod_personal` int(11) DEFAULT NULL,
  `cod_puntoventa` int(11) DEFAULT NULL,
  `diez_centimos` int(11) DEFAULT NULL,
  `veinte_centimos` int(11) DEFAULT NULL,
  `cincuenta_centimos` int(11) DEFAULT NULL,
  `un_sol` int(11) DEFAULT NULL,
  `dos_soles` int(11) DEFAULT NULL,
  `cinco_soles` int(11) DEFAULT NULL,
  `diez_soles` int(11) DEFAULT NULL,
  `veinte_soles` int(11) DEFAULT NULL,
  `cincuenta_soles` int(11) DEFAULT NULL,
  `cien_soles` int(11) DEFAULT NULL,
  `doscientos_soles` int(11) DEFAULT NULL,
  `total_dinero_apertura` double DEFAULT NULL,
  `total_dinero_cierre` double DEFAULT NULL,
  `total_gasto_diario` double DEFAULT NULL,
  `faltante` double DEFAULT NULL,
  `estado` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `apertura_cajas`
--

INSERT INTO `apertura_cajas` (`cod_apertura`, `fecha_creacion`, `fecha_apertura`, `fecha_cierre`, `nombre_caja`, `turno`, `cod_personal`, `cod_puntoventa`, `diez_centimos`, `veinte_centimos`, `cincuenta_centimos`, `un_sol`, `dos_soles`, `cinco_soles`, `diez_soles`, `veinte_soles`, `cincuenta_soles`, `cien_soles`, `doscientos_soles`, `total_dinero_apertura`, `total_dinero_cierre`, `total_gasto_diario`, `faltante`, `estado`) VALUES
(1, '2022-01-08', '2022-01-08 23:41:59', '2022-03-22 23:56:12', 'Caja-T3', NULL, 5, 10, NULL, NULL, 0, 0, 0, 5, 3, 5, 0, 0, NULL, 155, 0, NULL, NULL, 'Cerrado'),
(2, '2022-03-22', '2022-03-22 20:46:14', '2022-03-22 23:10:44', 'Caja-T2', NULL, 7, 11, NULL, NULL, 12, 0, 0, 0, 0, 12, 0, 0, NULL, 246, 222, NULL, NULL, 'Cerrado'),
(3, '2022-03-22', '2022-03-22 23:56:34', NULL, 'Caja-T3', NULL, 5, 10, NULL, NULL, 0, 0, 0, 5, 5, 5, 0, 0, NULL, 175, NULL, NULL, NULL, 'Aperturado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargos_personal`
--

CREATE TABLE `cargos_personal` (
  `cod_cargo` int(11) NOT NULL,
  `cargo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `cargos_personal`
--

INSERT INTO `cargos_personal` (`cod_cargo`, `cargo`, `estado`) VALUES
(1, 'Super Administrador', 'A'),
(2, 'Ventas', 'A'),
(5, 'Contabilidad', 'A'),
(4, 'Administrador', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria_productos`
--

CREATE TABLE `categoria_productos` (
  `cod_categoria` int(11) NOT NULL,
  `categoria` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `categoria_productos`
--

INSERT INTO `categoria_productos` (`cod_categoria`, `categoria`, `estado`) VALUES
(1, 'Short', 'A'),
(2, 'Pantalon y Chavo', 'A'),
(3, 'Vestido Corto', 'A'),
(4, 'Vestido Largo', 'A'),
(5, 'Faldas', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `cod_cliente` int(11) NOT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `fecha_actualizacion` timestamp NULL DEFAULT NULL,
  `cod_personal` int(11) DEFAULT NULL,
  `cod_puntoventa` int(11) DEFAULT NULL,
  `nombres` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referencia` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono_fijo` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movil` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movil2` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cod_tipodoc` int(11) DEFAULT NULL,
  `num_documento` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_factura`
--

CREATE TABLE `detalle_factura` (
  `id_detalle` int(11) NOT NULL,
  `id_factura` int(11) DEFAULT NULL,
  `fecha_registro` date DEFAULT NULL,
  `producto` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `cod_puntoventa` int(11) DEFAULT NULL,
  `serie` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `incluye_igv` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `igv_unit` double DEFAULT NULL,
  `igv` double DEFAULT NULL,
  `precio_sin_igv` double DEFAULT NULL,
  `precio_con_igv` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `detalle_factura`
--

INSERT INTO `detalle_factura` (`id_detalle`, `id_factura`, `fecha_registro`, `producto`, `cantidad`, `precio`, `cod_puntoventa`, `serie`, `incluye_igv`, `igv_unit`, `igv`, `precio_sin_igv`, `precio_con_igv`) VALUES
(1, 1, '2022-03-22', 'Pantalon Economico S-M-L', 1, 14, 11, 'BB02', 'SI', 2.135593220339, 2.135593220339, 11.864406779661, 14),
(2, 1, '2022-03-22', 'Pantalon Con Vena S-M-L', 1, 14, 11, 'BB02', 'SI', 2.135593220339, 2.135593220339, 11.864406779661, 14),
(3, 1, '2022-03-22', 'Pantalon Ston Cuadros  S-M-L', 1, 32, 11, 'BB02', 'SI', 4.8813559322034, 4.8813559322034, 27.118644067797, 32),
(4, 2, '2022-03-22', 'Pantalon Economico S-M-L', 1, 14, 11, 'BB02', 'SI', 2.135593220339, 2.135593220339, 11.864406779661, 14),
(5, 2, '2022-03-22', 'Pantalon Ston Cuadros  S-M-L', 1, 32, 11, 'BB02', 'SI', 4.8813559322034, 4.8813559322034, 27.118644067797, 32),
(6, 3, '2022-03-22', 'Pantalon Con Vena S-M-L', 1, 14, 11, 'NN02', 'NO', 0, 0, 14, 14),
(7, 4, '2022-03-22', 'Pantalon Con Vena S-M-L', 1, 14, 11, 'BB02', 'SI', 2.135593220339, 2.135593220339, 11.864406779661, 14),
(8, 5, '2022-03-22', 'Pantalon Economico S-M-L', 1, 14, 11, 'FF02', 'SI', 2.135593220339, 2.135593220339, 11.864406779661, 14),
(9, 5, '2022-03-22', 'Pantalon Con Vena S-M-L', 1, 14, 11, 'FF02', 'SI', 2.135593220339, 2.135593220339, 11.864406779661, 14),
(10, 5, '2022-03-22', 'Pantalon Ston Cuadros  S-M-L', 1, 32, 11, 'FF02', 'SI', 4.8813559322034, 4.8813559322034, 27.118644067797, 32),
(11, 6, '2022-03-22', 'Pantalon Economico S-M-L', 2, 14, 11, 'BB02', 'SI', 2.135593220339, 4.271186440678, 23.728813559322, 28),
(12, 7, '2022-03-22', 'Short Jean Licra Verano S-M-L', 2, 10, 10, 'BB03', 'SI', 1.5254237288136, 3.0508474576271, 16.949152542373, 20),
(13, 7, '2022-03-22', 'Short Jean Demin Verano S-M-L', 3, 8, 10, 'BB03', 'SI', 1.2203389830508, 3.6610169491525, 20.338983050847, 24);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos_electronicos`
--

CREATE TABLE `documentos_electronicos` (
  `id_doc` int(11) NOT NULL,
  `ruc` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `obs` text COLLATE utf8_unicode_ci,
  `url_xml` text COLLATE utf8_unicode_ci,
  `hash_cpe` text COLLATE utf8_unicode_ci,
  `hash_cdr` text COLLATE utf8_unicode_ci,
  `msj_sunat` text COLLATE utf8_unicode_ci,
  `ruta_cdr` text COLLATE utf8_unicode_ci,
  `tipo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doc` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cliente` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresa`
--

CREATE TABLE `empresa` (
  `id_empresa` int(11) NOT NULL,
  `ruc` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razon_social` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre_comercial` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `movil` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_sol` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clave_sol` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `certificado` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clave_certificado` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clave_borrar` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `empresa`
--

INSERT INTO `empresa` (`id_empresa`, `ruc`, `razon_social`, `nombre_comercial`, `direccion`, `telefono`, `movil`, `email`, `tipo`, `usuario_sol`, `clave_sol`, `certificado`, `clave_certificado`, `clave_borrar`) VALUES
(1, '102572545710', 'Abel Espinza Herrera', 'AE Studio', 'Jr. Manuel Scorza 161 La Molina', '977968777', '977968777', 'abel@abelespinoza.com', '3', 'MODDATOS', 'moddatos', 'certificado-prueba2.pfx', '123456789', '123456789');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `id_factura` int(11) NOT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `fecha_actualizacion` timestamp NULL DEFAULT NULL,
  `codigo_compro` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serie` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `num_comprobante` int(11) DEFAULT NULL,
  `fecha_registro` date DEFAULT NULL,
  `razon_social` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_tipodoc` int(11) DEFAULT NULL,
  `numero_documento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion_empresa` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_cliente` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forma_pago` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monto_pagar` double DEFAULT NULL,
  `total_igv` double DEFAULT NULL,
  `total_grabadas` double DEFAULT NULL,
  `total_monto` double DEFAULT NULL,
  `pago_transferencia` double DEFAULT NULL,
  `pago_efectivo` double DEFAULT NULL,
  `pago_vuelto` double DEFAULT NULL,
  `cod_personal` int(11) DEFAULT NULL,
  `fecha_enviosunat` date DEFAULT NULL,
  `doc_modificado` int(11) DEFAULT NULL,
  `cod_tipo_motivo` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_tipo_compro_modif` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruta_xml` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruta_cdr` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_puntoventa` int(11) DEFAULT NULL,
  `cod_apertura` int(11) DEFAULT NULL,
  `pdf` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacion` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vaucher` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`id_factura`, `fecha_creacion`, `fecha_actualizacion`, `codigo_compro`, `serie`, `num_comprobante`, `fecha_registro`, `razon_social`, `cod_tipodoc`, `numero_documento`, `direccion_empresa`, `email_cliente`, `forma_pago`, `monto_pagar`, `total_igv`, `total_grabadas`, `total_monto`, `pago_transferencia`, `pago_efectivo`, `pago_vuelto`, `cod_personal`, `fecha_enviosunat`, `doc_modificado`, `cod_tipo_motivo`, `cod_tipo_compro_modif`, `ruta_xml`, `ruta_cdr`, `cod_puntoventa`, `cod_apertura`, `pdf`, `observacion`, `vaucher`, `estado`) VALUES
(1, '2022-03-22 14:31:56', '2022-03-22 14:31:56', '03', 'BB02', 1, '2022-03-22', '', 2, '', '', '', 'Contado', NULL, 4.8813559322034, 50.847457627119, 60, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, 11, 2, '102572545710-BB02-00000001.pdf', NULL, NULL, 'Por Enviar'),
(2, '2022-03-22 14:39:25', '2022-03-22 14:39:25', '03', 'BB02', 2, '2022-03-22', '', 2, '', '', '', 'Contado', NULL, 4.8813559322034, 38.983050847458, 46, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, 11, 2, '102572545710-BB02-00000002.pdf', NULL, NULL, 'Por Enviar'),
(3, '2022-03-22 15:50:19', '2022-03-22 15:50:19', '100', 'NN02', 1, '2022-03-22', '', 0, '', '', '', 'Contado', NULL, 0, 14, 14, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, 11, 2, '102572545710-NN02-00000001.pdf', NULL, NULL, 'Por Enviar'),
(4, '2022-03-22 15:59:37', '2022-03-22 15:59:37', '03', 'BB02', 3, '2022-03-22', 'ESPINOZA HERRERA ABEL', 2, '25725457', '', 'abel@abelespinoza.com', 'Contado', NULL, 2.135593220339, 11.864406779661, 14, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, 11, 2, NULL, NULL, NULL, 'Por Enviar'),
(5, '2022-03-22 16:24:44', '2022-03-22 16:24:44', '01', 'FF02', 1, '2022-03-22', 'CPW Training Center', 1, '12022336545', 'Jr. Manuel Scorza 161', 'contacto@cursos-paginas-web.com', 'Contado', NULL, 4.8813559322034, 50.847457627119, 60, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, 11, 2, '102572545710-FF02-00000001.pdf', NULL, NULL, 'Por Enviar'),
(6, '2022-03-22 20:59:59', '2022-03-22 20:59:59', '03', 'BB02', 4, '2022-03-22', 'ESPINOZA HERRERA ABEL', 2, '25725457', 'Jr. Manuel Scorza 161', 'abel@abelespinoza.com', 'Contado', NULL, 4.271186440678, 23.728813559322, 28, 20, 10, 2, 7, NULL, NULL, NULL, NULL, NULL, NULL, 11, 2, '102572545710-BB02-00000004.pdf', 'Cliente VIP Frecuente', NULL, 'Por Enviar'),
(7, '2022-03-22 23:58:12', '2022-03-22 23:58:12', '03', 'BB03', 1, '2022-03-22', 'Juan Perez Ramos', 2, '25725457', 'Jr. Lima 124 SMP', 'juan@gmail.com', 'Contado', NULL, 3.6610169491525, 37.28813559322, 44, 0, 0, 0, 5, NULL, NULL, NULL, NULL, NULL, NULL, 10, 3, '102572545710-BB03-00000001.pdf', '', NULL, 'Por Enviar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cod_producto` int(11) DEFAULT NULL,
  `num_operacion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaded` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `files`
--

INSERT INTO `files` (`id`, `file_name`, `cod_producto`, `num_operacion`, `uploaded`) VALUES
(1, 'proyecto1.jpg', 2, '211203105248', '2021-12-03 11:31:50'),
(2, 'proyecto2.jpg', 2, '211203105248', '2021-12-03 11:31:57'),
(3, 'proyecto3.jpg', 2, '211203105248', '2021-12-03 11:32:00'),
(9, 'origami-fuscia.png', NULL, NULL, '0000-00-00 00:00:00'),
(10, 'portada-curso.png', NULL, NULL, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingreso_stock`
--

CREATE TABLE `ingreso_stock` (
  `cod_ingreso` int(11) NOT NULL,
  `fecha_entrada` date DEFAULT NULL,
  `cod_puntoventa` int(11) DEFAULT NULL,
  `codigo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre_producto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock_ingresado` int(11) DEFAULT NULL,
  `archivo_csv` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ingreso_stock`
--

INSERT INTO `ingreso_stock` (`cod_ingreso`, `fecha_entrada`, `cod_puntoventa`, `codigo`, `nombre_producto`, `stock_ingresado`, `archivo_csv`) VALUES
(1, '2021-12-11', 12, 'SCCE-SML', 'Short Chalis Color Entero S-M-L', 150, 'stock-productos.csv'),
(2, '2021-12-11', 12, 'SCE-SML', 'Short Chalis Estampado S-M-L', 150, 'stock-productos.csv'),
(3, '2021-12-11', 12, 'SCCV-SML', 'Short Chalis Con Vena S-M-L', 150, 'stock-productos.csv'),
(4, '2021-12-11', 12, 'SSCL-SML', 'Short Ston Con Lazo S-M-L', 150, 'stock-productos.csv'),
(5, '2021-12-11', 12, 'SCS-SML', 'Short Cargo Ston S-M-L', 150, 'stock-productos.csv'),
(6, '2021-12-11', 12, 'SC-SML', 'Short Cuadros S-M-L', 150, 'stock-productos.csv'),
(7, '2021-12-11', 12, 'SL-SML', 'Short Lino S-M-L', 150, 'stock-productos.csv'),
(8, '2021-12-11', 12, 'SCCE-Nina', 'Short Chalis Color Entero Ni?a', 150, 'stock-productos.csv'),
(9, '2021-12-11', 12, 'SCE-Nina', 'Short Chalis Estampado Ni?a', 150, 'stock-productos.csv'),
(10, '2021-12-11', 12, 'SPCE-SML', 'Short Piel Color Entero S-M-L', 150, 'stock-productos.csv'),
(11, '2021-12-11', 12, 'SPR-SML', 'Short Piel Rayas S-M-L', 150, 'stock-productos.csv'),
(12, '2021-12-11', 12, 'SPM-SML', 'Short Piel Minipri S-M-L', 150, 'stock-productos.csv'),
(13, '2021-12-11', 12, 'PE-SML', 'Pantalon Economico S-M-L', 150, 'stock-productos.csv'),
(14, '2021-12-11', 12, 'PCV-SML', 'Pantalon Con Vena S-M-L', 150, 'stock-productos.csv'),
(15, '2021-12-11', 12, 'PC-SML', 'Pantalon Catania S-M-L', 150, 'stock-productos.csv'),
(16, '2021-12-11', 12, 'PSC-SML', 'Pantalon Ston Cuadros  S-M-L', 150, 'stock-productos.csv'),
(17, '2021-12-11', 12, 'PL-SML', 'Pantalon Loma S-M-L', 150, 'stock-productos.csv'),
(18, '2021-12-11', 12, 'PP-SML', 'Pantalon Palazo S-M-L', 150, 'stock-productos.csv'),
(19, '2021-12-11', 12, 'PJ-SML', 'Pantalon Jogger S-M-L', 150, 'stock-productos.csv'),
(20, '2021-12-11', 12, 'PPM-Adulto', 'Pantalon Piel Minipri Adulto', 150, 'stock-productos.csv'),
(21, '2021-12-11', 12, 'PPM-Nina', 'Pantalon Piel Minipri Ni?a', 150, 'stock-productos.csv'),
(22, '2021-12-11', 12, 'PPR-SML', 'Pantalon Piel Rayas S-M-L', 150, 'stock-productos.csv'),
(23, '2021-12-11', 12, 'PPCE-SML', 'Pantalon Piel Color Entero S-M-L', 150, 'stock-productos.csv'),
(24, '2021-12-11', 12, 'CE-SML', 'Chavo Economico S-M-L', 150, 'stock-productos.csv'),
(25, '2021-12-11', 12, 'CPMN-468', 'Chavo Piel Minipri Ni?a 4-6-8', 150, 'stock-productos.csv'),
(26, '2021-12-11', 12, 'CPMN-10121416', 'Chavo Piel Minipri Ni?a 10-12-14-16', 150, 'stock-productos.csv'),
(27, '2021-12-11', 12, 'CPM-Adulto', 'Chavo Piel Minipri Adulto', 150, 'stock-productos.csv'),
(28, '2021-12-11', 12, 'BC-SML', 'Bermuda Caballero S-M-L', 150, 'stock-productos.csv'),
(29, '2021-12-11', 12, 'CL-SML', 'Chavo Lino S-M-L', 150, 'stock-productos.csv'),
(30, '2021-12-11', 12, 'CPR-SML', 'Chavo Piel Rayas S-M-L', 150, 'stock-productos.csv'),
(31, '2021-12-11', 12, 'CPCE-SML', 'Chavo Piel Color Entero S-M-L', 150, 'stock-productos.csv'),
(32, '2021-12-11', 12, 'VPCE', 'Vestido Paty Corto Estampado', 150, 'stock-productos.csv'),
(33, '2021-12-11', 12, 'VJCE', 'Vestido Jalapita Corto Estampado', 150, 'stock-productos.csv'),
(34, '2021-12-11', 12, 'VCCCE', 'Vestido Con Copa Corto Estampado', 150, 'stock-productos.csv'),
(35, '2021-12-11', 12, 'VECE', 'Vestido Ela Corto Estampado', 150, 'stock-productos.csv'),
(36, '2021-12-11', 12, 'VCACE', 'Vestido Con Amarre Corto Estampado', 150, 'stock-productos.csv'),
(37, '2021-12-11', 12, 'VETCE', 'Vestido Eliza Tira Corto Estampado', 150, 'stock-productos.csv'),
(38, '2021-12-11', 12, 'VMACE', 'Vestido Manga Acero Corto Estampado', 150, 'stock-productos.csv'),
(39, '2021-12-11', 12, 'VCMCE', 'Vestido Con Manga Corto Estampado', 150, 'stock-productos.csv'),
(40, '2021-12-11', 12, 'VECCE', 'Vestido Ela Corto Color Entero', 150, 'stock-productos.csv'),
(41, '2021-12-11', 12, 'VLCCE', 'Vestido Lazo al costado Corto Color Entero', 150, 'stock-productos.csv'),
(42, '2021-12-11', 12, 'VMACCE', 'Vestido Manga Acero Corto Color Entero', 150, 'stock-productos.csv'),
(43, '2021-12-11', 12, 'VCCCE', 'Vestido Cargo Corto Color Entero', 150, 'stock-productos.csv'),
(44, '2021-12-11', 12, 'VAPCCE', 'Vestido Amarre en el Pecho Corto Color Entero', 150, 'stock-productos.csv'),
(45, '2021-12-11', 12, 'ESCCE', 'Enterizo Susana Corto Color Entero', 150, 'stock-productos.csv'),
(46, '2021-12-11', 12, 'ERCCE', 'Enterizo Rumbera Corto Color Entero', 150, 'stock-productos.csv'),
(47, '2021-12-11', 12, 'VJE', 'Vestido Jalapita Estampado', 150, 'stock-productos.csv'),
(48, '2021-12-11', 12, 'VYE', 'Vestido Yeni Estampado', 150, 'stock-productos.csv'),
(49, '2021-12-11', 12, 'VETE', 'Vestido Eliza Tira Estampado', 150, 'stock-productos.csv'),
(50, '2021-12-11', 12, 'VBE', 'Vestido Bolas Estampado', 150, 'stock-productos.csv'),
(51, '2021-12-11', 12, 'VCE', 'Vestido Cruzado Estampado', 150, 'stock-productos.csv'),
(52, '2021-12-11', 12, 'VEE', 'Vestido Ela Estampado', 150, 'stock-productos.csv'),
(53, '2021-12-11', 12, 'VBLE', 'Vestido Betty Largo Estampado', 150, 'stock-productos.csv'),
(54, '2021-12-11', 12, 'VELE', 'Vestido Estela Largo Estampado', 150, 'stock-productos.csv'),
(55, '2021-12-11', 12, 'VHE', 'Vestido Hermana Estampado', 150, 'stock-productos.csv'),
(56, '2021-12-11', 12, 'VACE', 'Vestido Argolla Color Entero', 150, 'stock-productos.csv'),
(57, '2021-12-11', 12, 'VMACE', 'Vestido Manga Acero Color Entero', 150, 'stock-productos.csv'),
(58, '2021-12-11', 12, 'VAPCE', 'Vestido Amarre en el Pecho Color Entero', 150, 'stock-productos.csv'),
(59, '2021-12-11', 12, 'VSC', 'Vestido Ston Cuadros', 150, 'stock-productos.csv'),
(60, '2021-12-11', 12, 'JCS-M', 'Jamper Cuadros S-M', 150, 'stock-productos.csv'),
(61, '2021-12-11', 12, 'FS-SML', 'Falda Ston S-M-L', 150, 'stock-productos.csv'),
(62, '2021-12-11', 12, 'FL-SML', 'Falda Loma S-M-L', 150, 'stock-productos.csv'),
(63, '2021-12-11', 12, 'FSC-SML', 'Falda Short Cuadros S-M-L', 150, 'stock-productos.csv'),
(64, '2021-12-11', 12, 'FCC-SML', 'Falda Corta Chalis S-M-L', 150, 'stock-productos.csv'),
(65, '2021-12-11', 12, 'FC-SML', 'Faldon Chalis S-M-L', 150, 'stock-productos.csv'),
(66, '2021-12-11', 12, 'SJDV-SML', 'Short Jean Demin Verano S-M-L', 150, 'stock-productos-2.csv'),
(67, '2021-12-11', 12, 'SJNV-SML', 'Short Jean Nevado Verano S-M-L', 150, 'stock-productos-2.csv'),
(68, '2021-12-11', 12, 'SJLV-SML', 'Short Jean Licra Verano S-M-L', 150, 'stock-productos-2.csv');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas`
--

CREATE TABLE `marcas` (
  `cod_marca` int(11) NOT NULL,
  `marca` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `marcas`
--

INSERT INTO `marcas` (`cod_marca`, `marca`, `estado`) VALUES
(1, 'Kids Fashion', 'A'),
(2, 'Chupetin', 'A'),
(3, 'Divas Girls', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos`
--

CREATE TABLE `modulos` (
  `cod_modulo` int(11) NOT NULL,
  `nombre_modulo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icono` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orden` int(11) DEFAULT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `modulos`
--

INSERT INTO `modulos` (`cod_modulo`, `nombre_modulo`, `icono`, `orden`, `estado`) VALUES
(1, 'Empresa', 'mdi mdi-home-city-outline', 1, 'A'),
(2, 'Ventas', 'mdi mdi-cash-register', 2, 'A'),
(3, 'Fact. Electrónica', 'mdi mdi-file-document-multiple', 3, 'A'),
(4, 'Almacen', 'mdi mdi-database', 4, 'A'),
(5, 'Ingresos y Salidas', 'mdi mdi-database-export', 5, 'A'),
(6, 'Mantenimientos', 'mdi mdi-saw-blade', 6, 'A'),
(7, 'Reportes', 'mdi mdi-printer', 7, 'A'),
(8, 'Base de Datos', 'mdi mdi-database', 8, 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `motivo_nota_credito`
--

CREATE TABLE `motivo_nota_credito` (
  `cod_motivo` int(11) NOT NULL,
  `codigo` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `motivo_nota_credito`
--

INSERT INTO `motivo_nota_credito` (`cod_motivo`, `codigo`, `descripcion`, `estado`) VALUES
(1, '01', 'Anulación de la operación', 'A'),
(2, '02', 'Anulación por error en el RUC', 'A'),
(3, '03', 'Corrección por error en la descripción', 'A'),
(4, '04', 'Descuento global', 'A'),
(5, '05', 'Descuento por ítem', 'A'),
(6, '06', 'Devolución total', 'A'),
(7, '07', 'Devolución por ítem', 'A'),
(8, '08', 'Bonificación', 'A'),
(9, '09', 'Disminución en el valor', 'A'),
(10, '10', 'Otros Conceptos', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal`
--

CREATE TABLE `personal` (
  `cod_personal` int(11) NOT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `fecha_actualizacion` timestamp NULL DEFAULT NULL,
  `cod_puntoventa` int(11) DEFAULT NULL,
  `nombres` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_tipodoc` int(11) DEFAULT NULL,
  `num_documento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `movil` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cargo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area_trabajo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `ingreso_planilla` date DEFAULT NULL,
  `sueldo_mensual` double DEFAULT NULL,
  `sueldo_quincena` double DEFAULT NULL,
  `pago_diario` double DEFAULT NULL,
  `costo_hora` double DEFAULT NULL,
  `costo_minuto` double DEFAULT NULL,
  `imagen` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clave` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accesos` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `personal`
--

INSERT INTO `personal` (`cod_personal`, `fecha_creacion`, `fecha_actualizacion`, `cod_puntoventa`, `nombres`, `cod_tipodoc`, `num_documento`, `email`, `movil`, `cargo`, `area_trabajo`, `fecha_ingreso`, `ingreso_planilla`, `sueldo_mensual`, `sueldo_quincena`, `pago_diario`, `costo_hora`, `costo_minuto`, `imagen`, `usuario`, `clave`, `accesos`, `estado`) VALUES
(1, NULL, '2021-12-31 06:44:25', 1, 'Abel Espinoza Herrera', 1, '25725457', 'abel@abelespinoza.com', '977968777', 'Super Administrador', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, 'perfil-abel.png', '0913fc78c5b368bbe81809ebc107181a7b4847ef', 'ae9ba7e4b90600c0b9c19f50253a299fee68ff2a', 'SI', 'A'),
(5, '2021-12-24 17:48:23', '2022-03-21 21:49:20', 10, 'Raul Salazar Robles', 1, '36548559', 'raul@gmail.com', '993654586', 'Ventas', 'Vendedor', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, 'imgperfil.png', 'a446e4be4f520d74e26b61915ee245e011ff006f', '4fa67f1bb557f0a87b102515e3c8ed99dbb92f64', 'NO', 'A'),
(6, '2021-12-31 06:17:17', '2021-12-31 06:17:17', 12, 'Ezio Espinoza T', 1, '25698789', 'exio@gmail.com', '99365698', 'Super Administrador', 'Almacen', '2021-12-31', NULL, NULL, NULL, NULL, NULL, NULL, 'avatar2.png', 'c50b81eb02a278b935991bf2aa43c79c6ad8480f', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'SI', 'A'),
(7, '2021-12-31 06:20:25', '2022-03-21 15:52:22', 11, 'Alison Espinoza T', 1, '89653214', 'aliso@gmail.com', '96859699', 'Ventas', 'Tienda Gamarra', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, '', 'fa026963b31a69aeb6bcdfbafc66a54c6597d2b9', '44e2c5a04d943869ad70778d25aa2d9408c2c630', 'NO', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `cod_producto` int(11) NOT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `fecha_actualizacion` timestamp NULL DEFAULT NULL,
  `cod_categoria` int(11) DEFAULT NULL,
  `cod_marca` int(11) DEFAULT NULL,
  `cod_personal` int(11) DEFAULT NULL,
  `codigo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre_producto` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imagen` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `unidad_medida` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock_actual` int(11) DEFAULT NULL,
  `stock_minimo` int(11) DEFAULT NULL,
  `precio_unitario` double DEFAULT NULL,
  `precio_cuarto` double DEFAULT NULL,
  `precio_mayor` double DEFAULT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`cod_producto`, `fecha_creacion`, `fecha_actualizacion`, `cod_categoria`, `cod_marca`, `cod_personal`, `codigo`, `nombre_producto`, `imagen`, `descripcion`, `unidad_medida`, `stock_actual`, `stock_minimo`, `precio_unitario`, `precio_cuarto`, `precio_mayor`, `estado`) VALUES
(1, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SCCE-SML', 'Short Chalis Color Entero S-M-L', NULL, NULL, 'Unidad', 200, NULL, 8, 7, 6.5, 'A'),
(2, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SCE-SML', 'Short Chalis Estampado S-M-L', NULL, NULL, 'Unidad', 200, NULL, 8, 7, 6.5, 'A'),
(3, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SCCV-SML', 'Short Chalis Con Vena S-M-L', NULL, NULL, 'Unidad', 200, NULL, 10, 9, 8.5, 'A'),
(4, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SSCL-SML', 'Short Ston Con Lazo S-M-L', NULL, NULL, 'Unidad', 200, NULL, 15, 14, 13, 'A'),
(5, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SCS-SML', 'Short Cargo Ston S-M-L', NULL, NULL, 'Unidad', 200, NULL, 15, 14, 13, 'A'),
(6, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SC-SML', 'Short Cuadros S-M-L', NULL, NULL, 'Unidad', 200, NULL, 17, 16, 15, 'A'),
(7, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SL-SML', 'Short Lino S-M-L', NULL, NULL, 'Unidad', 200, NULL, 12, 11, 10, 'A'),
(8, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SCCE-Nina', 'Short Chalis Color Entero Ni?a', NULL, NULL, 'Unidad', 200, NULL, 6, 5, 4.5, 'A'),
(9, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SCE-Nina', 'Short Chalis Estampado Ni?a', NULL, NULL, 'Unidad', 200, NULL, 6, 5, 4.5, 'A'),
(10, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SPCE-SML', 'Short Piel Color Entero S-M-L', NULL, NULL, 'Unidad', 200, NULL, 9, 8, 7, 'A'),
(11, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SPR-SML', 'Short Piel Rayas S-M-L', NULL, NULL, 'Unidad', 200, NULL, 9, 8, 7, 'A'),
(12, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 1, 1, 1, 'SPM-SML', 'Short Piel Minipri S-M-L', NULL, NULL, 'Unidad', 200, NULL, 7, 6, 5, 'A'),
(13, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PE-SML', 'Pantalon Economico S-M-L', NULL, NULL, 'Unidad', 200, NULL, 14, 13, 12, 'A'),
(14, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PCV-SML', 'Pantalon Con Vena S-M-L', NULL, NULL, 'Unidad', 200, NULL, 14, 13, 12, 'A'),
(15, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PC-SML', 'Pantalon Catania S-M-L', NULL, NULL, 'Unidad', 200, NULL, 30, 29, 28, 'A'),
(16, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PSC-SML', 'Pantalon Ston Cuadros  S-M-L', NULL, NULL, 'Unidad', 200, NULL, 32, 31, 30, 'A'),
(17, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PL-SML', 'Pantalon Loma S-M-L', NULL, NULL, 'Unidad', 200, NULL, 32, 31, 30, 'A'),
(18, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PP-SML', 'Pantalon Palazo S-M-L', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(19, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PJ-SML', 'Pantalon Jogger S-M-L', NULL, NULL, 'Unidad', 200, NULL, 24, 23, 22, 'A'),
(20, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PPM-Adulto', 'Pantalon Piel Minipri Adulto', NULL, NULL, 'Unidad', 200, NULL, 10, 9, 8.5, 'A'),
(21, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PPM-Nina', 'Pantalon Piel Minipri Ni?a', NULL, NULL, 'Unidad', 200, NULL, 8, 7, 6, 'A'),
(22, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PPR-SML', 'Pantalon Piel Rayas S-M-L', NULL, NULL, 'Unidad', 200, NULL, 12, 11, 10, 'A'),
(23, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'PPCE-SML', 'Pantalon Piel Color Entero S-M-L', NULL, NULL, 'Unidad', 200, NULL, 12, 11, 10, 'A'),
(24, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'CE-SML', 'Chavo Economico S-M-L', NULL, NULL, 'Unidad', 200, NULL, 12, 11, 10, 'A'),
(25, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'CPMN-468', 'Chavo Piel Minipri Ni?a 4-6-8', NULL, NULL, 'Unidad', 200, NULL, 8, 7, 6, 'A'),
(26, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'CPMN-10121416', 'Chavo Piel Minipri Ni?a 10-12-14-16', NULL, NULL, 'Unidad', 200, NULL, 8, 7, 6.5, 'A'),
(27, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'CPM-Adulto', 'Chavo Piel Minipri Adulto', NULL, NULL, 'Unidad', 200, NULL, 9, 8, 7.5, 'A'),
(28, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'BC-SML', 'Bermuda Caballero S-M-L', NULL, NULL, 'Unidad', 200, NULL, 17, 16, 15, 'A'),
(29, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'CL-SML', 'Chavo Lino S-M-L', NULL, NULL, 'Unidad', 200, NULL, 17, 16, 15, 'A'),
(30, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'CPR-SML', 'Chavo Piel Rayas S-M-L', NULL, NULL, 'Unidad', 200, NULL, 10, 9, 8.5, 'A'),
(31, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 2, 1, 1, 'CPCE-SML', 'Chavo Piel Color Entero S-M-L', NULL, NULL, 'Unidad', 200, NULL, 10, 9, 8.5, 'A'),
(32, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VPCE', 'Vestido Paty Corto Estampado', NULL, NULL, 'Unidad', 200, NULL, 19, 18, 17, 'A'),
(33, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VJCE', 'Vestido Jalapita Corto Estampado', NULL, NULL, 'Unidad', 200, NULL, 19, 18, 17, 'A'),
(34, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VCCCE', 'Vestido Con Copa Corto Estampado', NULL, NULL, 'Unidad', -100, NULL, 22, 21, 20, 'A'),
(35, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VECE', 'Vestido Ela Corto Estampado', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(36, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VCACE', 'Vestido Con Amarre Corto Estampado', NULL, NULL, 'Unidad', 200, NULL, 19, 18, 17, 'A'),
(37, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VETCE', 'Vestido Eliza Tira Corto Estampado', NULL, NULL, 'Unidad', 200, NULL, 19, 18, 17, 'A'),
(38, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VMACE', 'Vestido Manga Acero Corto Estampado', NULL, NULL, 'Unidad', -100, NULL, 27, 26, 25, 'A'),
(39, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VCMCE', 'Vestido Con Manga Corto Estampado', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(40, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VECCE', 'Vestido Ela Corto Color Entero', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(41, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VLCCE', 'Vestido Lazo al costado Corto Color Entero', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(42, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VMACCE', 'Vestido Manga Acero Corto Color Entero', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(43, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'VAPCCE', 'Vestido Amarre en el Pecho Corto Color Entero', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(44, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'ESCCE', 'Enterizo Susana Corto Color Entero', NULL, NULL, 'Unidad', 200, NULL, 25, 24, 23, 'A'),
(45, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 3, 1, 1, 'ERCCE', 'Enterizo Rumbera Corto Color Entero', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(46, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VJE', 'Vestido Jalapita Estampado', NULL, NULL, 'Unidad', 200, NULL, 23, 22, 21, 'A'),
(47, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VYE', 'Vestido Yeni Estampado', NULL, NULL, 'Unidad', 200, NULL, 23, 22, 21, 'A'),
(48, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VETE', 'Vestido Eliza Tira Estampado', NULL, NULL, 'Unidad', 200, NULL, 23, 22, 21, 'A'),
(49, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VBE', 'Vestido Bolas Estampado', NULL, NULL, 'Unidad', 200, NULL, 23, 22, 21, 'A'),
(50, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VCE', 'Vestido Cruzado Estampado', NULL, NULL, 'Unidad', 200, NULL, 23, 22, 21, 'A'),
(51, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VEE', 'Vestido Ela Estampado', NULL, NULL, 'Unidad', 200, NULL, 25, 24, 23, 'A'),
(52, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VBLE', 'Vestido Betty Largo Estampado', NULL, NULL, 'Unidad', 200, NULL, 27, 26, 25, 'A'),
(53, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VELE', 'Vestido Estela Largo Estampado', NULL, NULL, 'Unidad', 200, NULL, 27, 26, 25, 'A'),
(54, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VHE', 'Vestido Hermana Estampado', NULL, NULL, 'Unidad', 200, NULL, 27, 26, 25, 'A'),
(55, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VACE', 'Vestido Argolla Color Entero', NULL, NULL, 'Unidad', 200, NULL, 27, 26, 25, 'A'),
(56, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VAPCE', 'Vestido Amarre en el Pecho Color Entero', NULL, NULL, 'Unidad', 200, NULL, 27, 26, 25, 'A'),
(57, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'VSC', 'Vestido Ston Cuadros', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(58, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 4, 1, 1, 'JCS-M', 'Jamper Cuadros S-M', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(59, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 5, 1, 1, 'FS-SML', 'Falda Ston S-M-L', NULL, NULL, 'Unidad', 200, NULL, 20, 19, 18, 'A'),
(60, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 5, 1, 1, 'FL-SML', 'Falda Loma S-M-L', NULL, NULL, 'Unidad', 200, NULL, 22, 21, 20, 'A'),
(61, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 5, 1, 1, 'FSC-SML', 'Falda Short Cuadros S-M-L', NULL, NULL, 'Unidad', 200, NULL, 19, 18, 17, 'A'),
(62, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 5, 1, 1, 'FCC-SML', 'Falda Corta Chalis S-M-L', NULL, NULL, 'Unidad', 200, NULL, 13, 12, 11, 'A'),
(63, '2021-12-11 23:17:27', '2021-12-11 23:17:27', 5, 1, 1, 'FC-SML', 'Faldon Chalis S-M-L', NULL, NULL, 'Unidad', 200, NULL, 17, 16, 15, 'A'),
(64, '2021-12-11 23:27:43', '2021-12-11 23:27:43', 1, 2, 1, 'SJDV-SML', 'Short Jean Demin Verano S-M-L', NULL, NULL, 'Unidad', 500, NULL, 8, 7, 6.5, 'A'),
(65, '2021-12-11 23:27:43', '2021-12-11 23:27:43', 1, 2, 1, 'SJNV-SML', 'Short Jean Nevado Verano S-M-L', NULL, NULL, 'Unidad', 500, NULL, 8, 7, 6.5, 'A'),
(66, '2021-12-11 23:27:43', '2021-12-11 23:27:43', 1, 2, 1, 'SJLV-SML', 'Short Jean Licra Verano S-M-L', NULL, NULL, 'Unidad', 500, NULL, 10, 9, 8.5, 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos_ventas`
--

CREATE TABLE `puntos_ventas` (
  `cod_puntoventa` int(11) NOT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `nombre_puntoventa` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alias` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `puntos_ventas`
--

INSERT INTO `puntos_ventas` (`cod_puntoventa`, `fecha_creacion`, `nombre_puntoventa`, `alias`, `direccion`, `telefono`, `email`, `estado`) VALUES
(1, '2020-01-28 06:00:00', 'Principal', 'T1', 'Jr. Manuel Scorza 161 La Molina', '977968777', 'contacto@cursos-paginas-web.com', 'A'),
(12, '2021-12-11 18:32:00', 'Almacen', 'AL', 'Jr. Manuel Scorza 161 La Molina', '977968777', 'almacen@cursos-paginas-web.com', 'A'),
(10, '2021-11-26 23:47:38', 'Tienda La Rambla', 'T3', 'Av. Aviacion 123 San Borja', '257274', 'contac@as.com', 'A'),
(11, '2021-11-26 23:48:27', 'Tienda Gamarra', 'T2', 'Jr. Gamarra 123 La Victoria Lima Peru', '993654170', 'local1@abelespinoza.com', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `salida_stock`
--

CREATE TABLE `salida_stock` (
  `cod_salidastock` int(11) NOT NULL,
  `cod_puntoventa` int(11) DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `codigo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre_producto` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stock_salida` int(11) DEFAULT NULL,
  `archivo_csv` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `salida_stock`
--

INSERT INTO `salida_stock` (`cod_salidastock`, `cod_puntoventa`, `fecha_salida`, `codigo`, `nombre_producto`, `stock_salida`, `archivo_csv`) VALUES
(1, 1, '2022-03-27', 'SCCE-SML', 'Short Chalis Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(2, 1, '2022-03-27', 'SCE-SML', 'Short Chalis Estampado S-M-L', 100, 'stock-salida-productos.csv'),
(3, 1, '2022-03-27', 'SCCV-SML', 'Short Chalis Con Vena S-M-L', 100, 'stock-salida-productos.csv'),
(4, 1, '2022-03-27', 'SSCL-SML', 'Short Ston Con Lazo S-M-L', 100, 'stock-salida-productos.csv'),
(5, 1, '2022-03-27', 'SCS-SML', 'Short Cargo Ston S-M-L', 100, 'stock-salida-productos.csv'),
(6, 1, '2022-03-27', 'SC-SML', 'Short Cuadros S-M-L', 100, 'stock-salida-productos.csv'),
(7, 1, '2022-03-27', 'SL-SML', 'Short Lino S-M-L', 100, 'stock-salida-productos.csv'),
(8, 1, '2022-03-27', 'SCCE-Nina', 'Short Chalis Color Entero Ni?a', 100, 'stock-salida-productos.csv'),
(9, 1, '2022-03-27', 'SCE-Nina', 'Short Chalis Estampado Ni?a', 100, 'stock-salida-productos.csv'),
(10, 1, '2022-03-27', 'SPCE-SML', 'Short Piel Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(11, 1, '2022-03-27', 'SPR-SML', 'Short Piel Rayas S-M-L', 100, 'stock-salida-productos.csv'),
(12, 1, '2022-03-27', 'SPM-SML', 'Short Piel Minipri S-M-L', 100, 'stock-salida-productos.csv'),
(13, 1, '2022-03-27', 'PE-SML', 'Pantalon Economico S-M-L', 100, 'stock-salida-productos.csv'),
(14, 1, '2022-03-27', 'PCV-SML', 'Pantalon Con Vena S-M-L', 100, 'stock-salida-productos.csv'),
(15, 1, '2022-03-27', 'PC-SML', 'Pantalon Catania S-M-L', 100, 'stock-salida-productos.csv'),
(16, 1, '2022-03-27', 'PSC-SML', 'Pantalon Ston Cuadros  S-M-L', 100, 'stock-salida-productos.csv'),
(17, 1, '2022-03-27', 'PL-SML', 'Pantalon Loma S-M-L', 100, 'stock-salida-productos.csv'),
(18, 1, '2022-03-27', 'PP-SML', 'Pantalon Palazo S-M-L', 100, 'stock-salida-productos.csv'),
(19, 1, '2022-03-27', 'PJ-SML', 'Pantalon Jogger S-M-L', 100, 'stock-salida-productos.csv'),
(20, 1, '2022-03-27', 'PPM-Adulto', 'Pantalon Piel Minipri Adulto', 100, 'stock-salida-productos.csv'),
(21, 1, '2022-03-27', 'PPM-Nina', 'Pantalon Piel Minipri Ni?a', 100, 'stock-salida-productos.csv'),
(22, 1, '2022-03-27', 'PPR-SML', 'Pantalon Piel Rayas S-M-L', 100, 'stock-salida-productos.csv'),
(23, 1, '2022-03-27', 'PPCE-SML', 'Pantalon Piel Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(24, 1, '2022-03-27', 'CE-SML', 'Chavo Economico S-M-L', 100, 'stock-salida-productos.csv'),
(25, 1, '2022-03-27', 'CPMN-468', 'Chavo Piel Minipri Ni?a 4-6-8', 100, 'stock-salida-productos.csv'),
(26, 1, '2022-03-27', 'CPMN-10121416', 'Chavo Piel Minipri Ni?a 10-12-14-16', 100, 'stock-salida-productos.csv'),
(27, 1, '2022-03-27', 'CPM-Adulto', 'Chavo Piel Minipri Adulto', 100, 'stock-salida-productos.csv'),
(28, 1, '2022-03-27', 'BC-SML', 'Bermuda Caballero S-M-L', 100, 'stock-salida-productos.csv'),
(29, 1, '2022-03-27', 'CL-SML', 'Chavo Lino S-M-L', 100, 'stock-salida-productos.csv'),
(30, 1, '2022-03-27', 'CPR-SML', 'Chavo Piel Rayas S-M-L', 100, 'stock-salida-productos.csv'),
(31, 1, '2022-03-27', 'CPCE-SML', 'Chavo Piel Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(32, 1, '2022-03-27', 'VPCE', 'Vestido Paty Corto Estampado', 100, 'stock-salida-productos.csv'),
(33, 1, '2022-03-27', 'VJCE', 'Vestido Jalapita Corto Estampado', 100, 'stock-salida-productos.csv'),
(34, 1, '2022-03-27', 'VCCCE', 'Vestido Con Copa Corto Estampado', 100, 'stock-salida-productos.csv'),
(35, 1, '2022-03-27', 'VECE', 'Vestido Ela Corto Estampado', 100, 'stock-salida-productos.csv'),
(36, 1, '2022-03-27', 'VCACE', 'Vestido Con Amarre Corto Estampado', 100, 'stock-salida-productos.csv'),
(37, 1, '2022-03-27', 'VETCE', 'Vestido Eliza Tira Corto Estampado', 100, 'stock-salida-productos.csv'),
(38, 1, '2022-03-27', 'VMACE', 'Vestido Manga Acero Corto Estampado', 100, 'stock-salida-productos.csv'),
(39, 1, '2022-03-27', 'VCMCE', 'Vestido Con Manga Corto Estampado', 100, 'stock-salida-productos.csv'),
(40, 1, '2022-03-27', 'VECCE', 'Vestido Ela Corto Color Entero', 100, 'stock-salida-productos.csv'),
(41, 1, '2022-03-27', 'VLCCE', 'Vestido Lazo al costado Corto Color Entero', 100, 'stock-salida-productos.csv'),
(42, 1, '2022-03-27', 'VMACCE', 'Vestido Manga Acero Corto Color Entero', 100, 'stock-salida-productos.csv'),
(43, 1, '2022-03-27', 'VCCCE', 'Vestido Con Copa Corto Estampado', 100, 'stock-salida-productos.csv'),
(44, 1, '2022-03-27', 'VAPCCE', 'Vestido Amarre en el Pecho Corto Color Entero', 100, 'stock-salida-productos.csv'),
(45, 1, '2022-03-27', 'ESCCE', 'Enterizo Susana Corto Color Entero', 100, 'stock-salida-productos.csv'),
(46, 1, '2022-03-27', 'ERCCE', 'Enterizo Rumbera Corto Color Entero', 100, 'stock-salida-productos.csv'),
(47, 1, '2022-03-27', 'VJE', 'Vestido Jalapita Estampado', 100, 'stock-salida-productos.csv'),
(48, 1, '2022-03-27', 'VYE', 'Vestido Yeni Estampado', 100, 'stock-salida-productos.csv'),
(49, 1, '2022-03-27', 'VETE', 'Vestido Eliza Tira Estampado', 100, 'stock-salida-productos.csv'),
(50, 1, '2022-03-27', 'VBE', 'Vestido Bolas Estampado', 100, 'stock-salida-productos.csv'),
(51, 1, '2022-03-27', 'VCE', 'Vestido Cruzado Estampado', 100, 'stock-salida-productos.csv'),
(52, 1, '2022-03-27', 'VEE', 'Vestido Ela Estampado', 100, 'stock-salida-productos.csv'),
(53, 1, '2022-03-27', 'VBLE', 'Vestido Betty Largo Estampado', 100, 'stock-salida-productos.csv'),
(54, 1, '2022-03-27', 'VELE', 'Vestido Estela Largo Estampado', 100, 'stock-salida-productos.csv'),
(55, 1, '2022-03-27', 'VHE', 'Vestido Hermana Estampado', 100, 'stock-salida-productos.csv'),
(56, 1, '2022-03-27', 'VACE', 'Vestido Argolla Color Entero', 100, 'stock-salida-productos.csv'),
(57, 1, '2022-03-27', 'VMACE', 'Vestido Manga Acero Corto Estampado', 100, 'stock-salida-productos.csv'),
(58, 1, '2022-03-27', 'VAPCE', 'Vestido Amarre en el Pecho Color Entero', 100, 'stock-salida-productos.csv'),
(59, 1, '2022-03-27', 'VSC', 'Vestido Ston Cuadros', 100, 'stock-salida-productos.csv'),
(60, 1, '2022-03-27', 'JCS-M', 'Jamper Cuadros S-M', 100, 'stock-salida-productos.csv'),
(61, 1, '2022-03-27', 'FS-SML', 'Falda Ston S-M-L', 100, 'stock-salida-productos.csv'),
(62, 1, '2022-03-27', 'FL-SML', 'Falda Loma S-M-L', 100, 'stock-salida-productos.csv'),
(63, 1, '2022-03-27', 'FSC-SML', 'Falda Short Cuadros S-M-L', 100, 'stock-salida-productos.csv'),
(64, 1, '2022-03-27', 'FCC-SML', 'Falda Corta Chalis S-M-L', 100, 'stock-salida-productos.csv'),
(65, 1, '2022-03-27', 'FC-SML', 'Faldon Chalis S-M-L', 100, 'stock-salida-productos.csv'),
(66, 10, '2022-03-27', 'SCCE-SML', 'Short Chalis Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(67, 10, '2022-03-27', 'SCE-SML', 'Short Chalis Estampado S-M-L', 100, 'stock-salida-productos.csv'),
(68, 10, '2022-03-27', 'SCCV-SML', 'Short Chalis Con Vena S-M-L', 100, 'stock-salida-productos.csv'),
(69, 10, '2022-03-27', 'SSCL-SML', 'Short Ston Con Lazo S-M-L', 100, 'stock-salida-productos.csv'),
(70, 10, '2022-03-27', 'SCS-SML', 'Short Cargo Ston S-M-L', 100, 'stock-salida-productos.csv'),
(71, 10, '2022-03-27', 'SC-SML', 'Short Cuadros S-M-L', 100, 'stock-salida-productos.csv'),
(72, 10, '2022-03-27', 'SL-SML', 'Short Lino S-M-L', 100, 'stock-salida-productos.csv'),
(73, 10, '2022-03-27', 'SCCE-Nina', 'Short Chalis Color Entero Ni?a', 100, 'stock-salida-productos.csv'),
(74, 10, '2022-03-27', 'SCE-Nina', 'Short Chalis Estampado Ni?a', 100, 'stock-salida-productos.csv'),
(75, 10, '2022-03-27', 'SPCE-SML', 'Short Piel Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(76, 10, '2022-03-27', 'SPR-SML', 'Short Piel Rayas S-M-L', 100, 'stock-salida-productos.csv'),
(77, 10, '2022-03-27', 'SPM-SML', 'Short Piel Minipri S-M-L', 100, 'stock-salida-productos.csv'),
(78, 10, '2022-03-27', 'PE-SML', 'Pantalon Economico S-M-L', 100, 'stock-salida-productos.csv'),
(79, 10, '2022-03-27', 'PCV-SML', 'Pantalon Con Vena S-M-L', 100, 'stock-salida-productos.csv'),
(80, 10, '2022-03-27', 'PC-SML', 'Pantalon Catania S-M-L', 100, 'stock-salida-productos.csv'),
(81, 10, '2022-03-27', 'PSC-SML', 'Pantalon Ston Cuadros  S-M-L', 100, 'stock-salida-productos.csv'),
(82, 10, '2022-03-27', 'PL-SML', 'Pantalon Loma S-M-L', 100, 'stock-salida-productos.csv'),
(83, 10, '2022-03-27', 'PP-SML', 'Pantalon Palazo S-M-L', 100, 'stock-salida-productos.csv'),
(84, 10, '2022-03-27', 'PJ-SML', 'Pantalon Jogger S-M-L', 100, 'stock-salida-productos.csv'),
(85, 10, '2022-03-27', 'PPM-Adulto', 'Pantalon Piel Minipri Adulto', 100, 'stock-salida-productos.csv'),
(86, 10, '2022-03-27', 'PPM-Nina', 'Pantalon Piel Minipri Ni?a', 100, 'stock-salida-productos.csv'),
(87, 10, '2022-03-27', 'PPR-SML', 'Pantalon Piel Rayas S-M-L', 100, 'stock-salida-productos.csv'),
(88, 10, '2022-03-27', 'PPCE-SML', 'Pantalon Piel Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(89, 10, '2022-03-27', 'CE-SML', 'Chavo Economico S-M-L', 100, 'stock-salida-productos.csv'),
(90, 10, '2022-03-27', 'CPMN-468', 'Chavo Piel Minipri Ni?a 4-6-8', 100, 'stock-salida-productos.csv'),
(91, 10, '2022-03-27', 'CPMN-10121416', 'Chavo Piel Minipri Ni?a 10-12-14-16', 100, 'stock-salida-productos.csv'),
(92, 10, '2022-03-27', 'CPM-Adulto', 'Chavo Piel Minipri Adulto', 100, 'stock-salida-productos.csv'),
(93, 10, '2022-03-27', 'BC-SML', 'Bermuda Caballero S-M-L', 100, 'stock-salida-productos.csv'),
(94, 10, '2022-03-27', 'CL-SML', 'Chavo Lino S-M-L', 100, 'stock-salida-productos.csv'),
(95, 10, '2022-03-27', 'CPR-SML', 'Chavo Piel Rayas S-M-L', 100, 'stock-salida-productos.csv'),
(96, 10, '2022-03-27', 'CPCE-SML', 'Chavo Piel Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(97, 10, '2022-03-27', 'VPCE', 'Vestido Paty Corto Estampado', 100, 'stock-salida-productos.csv'),
(98, 10, '2022-03-27', 'VJCE', 'Vestido Jalapita Corto Estampado', 100, 'stock-salida-productos.csv'),
(99, 10, '2022-03-27', 'VCCCE', 'Vestido Con Copa Corto Estampado', 100, 'stock-salida-productos.csv'),
(100, 10, '2022-03-27', 'VECE', 'Vestido Ela Corto Estampado', 100, 'stock-salida-productos.csv'),
(101, 10, '2022-03-27', 'VCACE', 'Vestido Con Amarre Corto Estampado', 100, 'stock-salida-productos.csv'),
(102, 10, '2022-03-27', 'VETCE', 'Vestido Eliza Tira Corto Estampado', 100, 'stock-salida-productos.csv'),
(103, 10, '2022-03-27', 'VMACE', 'Vestido Manga Acero Corto Estampado', 100, 'stock-salida-productos.csv'),
(104, 10, '2022-03-27', 'VCMCE', 'Vestido Con Manga Corto Estampado', 100, 'stock-salida-productos.csv'),
(105, 10, '2022-03-27', 'VECCE', 'Vestido Ela Corto Color Entero', 100, 'stock-salida-productos.csv'),
(106, 10, '2022-03-27', 'VLCCE', 'Vestido Lazo al costado Corto Color Entero', 100, 'stock-salida-productos.csv'),
(107, 10, '2022-03-27', 'VMACCE', 'Vestido Manga Acero Corto Color Entero', 100, 'stock-salida-productos.csv'),
(108, 10, '2022-03-27', 'VCCCE', 'Vestido Con Copa Corto Estampado', 100, 'stock-salida-productos.csv'),
(109, 10, '2022-03-27', 'VAPCCE', 'Vestido Amarre en el Pecho Corto Color Entero', 100, 'stock-salida-productos.csv'),
(110, 10, '2022-03-27', 'ESCCE', 'Enterizo Susana Corto Color Entero', 100, 'stock-salida-productos.csv'),
(111, 10, '2022-03-27', 'ERCCE', 'Enterizo Rumbera Corto Color Entero', 100, 'stock-salida-productos.csv'),
(112, 10, '2022-03-27', 'VJE', 'Vestido Jalapita Estampado', 100, 'stock-salida-productos.csv'),
(113, 10, '2022-03-27', 'VYE', 'Vestido Yeni Estampado', 100, 'stock-salida-productos.csv'),
(114, 10, '2022-03-27', 'VETE', 'Vestido Eliza Tira Estampado', 100, 'stock-salida-productos.csv'),
(115, 10, '2022-03-27', 'VBE', 'Vestido Bolas Estampado', 100, 'stock-salida-productos.csv'),
(116, 10, '2022-03-27', 'VCE', 'Vestido Cruzado Estampado', 100, 'stock-salida-productos.csv'),
(117, 10, '2022-03-27', 'VEE', 'Vestido Ela Estampado', 100, 'stock-salida-productos.csv'),
(118, 10, '2022-03-27', 'VBLE', 'Vestido Betty Largo Estampado', 100, 'stock-salida-productos.csv'),
(119, 10, '2022-03-27', 'VELE', 'Vestido Estela Largo Estampado', 100, 'stock-salida-productos.csv'),
(120, 10, '2022-03-27', 'VHE', 'Vestido Hermana Estampado', 100, 'stock-salida-productos.csv'),
(121, 10, '2022-03-27', 'VACE', 'Vestido Argolla Color Entero', 100, 'stock-salida-productos.csv'),
(122, 10, '2022-03-27', 'VMACE', 'Vestido Manga Acero Corto Estampado', 100, 'stock-salida-productos.csv'),
(123, 10, '2022-03-27', 'VAPCE', 'Vestido Amarre en el Pecho Color Entero', 100, 'stock-salida-productos.csv'),
(124, 10, '2022-03-27', 'VSC', 'Vestido Ston Cuadros', 100, 'stock-salida-productos.csv'),
(125, 10, '2022-03-27', 'JCS-M', 'Jamper Cuadros S-M', 100, 'stock-salida-productos.csv'),
(126, 10, '2022-03-27', 'FS-SML', 'Falda Ston S-M-L', 100, 'stock-salida-productos.csv'),
(127, 10, '2022-03-27', 'FL-SML', 'Falda Loma S-M-L', 100, 'stock-salida-productos.csv'),
(128, 10, '2022-03-27', 'FSC-SML', 'Falda Short Cuadros S-M-L', 100, 'stock-salida-productos.csv'),
(129, 10, '2022-03-27', 'FCC-SML', 'Falda Corta Chalis S-M-L', 100, 'stock-salida-productos.csv'),
(130, 10, '2022-03-27', 'FC-SML', 'Faldon Chalis S-M-L', 100, 'stock-salida-productos.csv'),
(131, 11, '2022-03-27', 'SCCE-SML', 'Short Chalis Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(132, 11, '2022-03-27', 'SCE-SML', 'Short Chalis Estampado S-M-L', 100, 'stock-salida-productos.csv'),
(133, 11, '2022-03-27', 'SCCV-SML', 'Short Chalis Con Vena S-M-L', 100, 'stock-salida-productos.csv'),
(134, 11, '2022-03-27', 'SSCL-SML', 'Short Ston Con Lazo S-M-L', 100, 'stock-salida-productos.csv'),
(135, 11, '2022-03-27', 'SCS-SML', 'Short Cargo Ston S-M-L', 100, 'stock-salida-productos.csv'),
(136, 11, '2022-03-27', 'SC-SML', 'Short Cuadros S-M-L', 100, 'stock-salida-productos.csv'),
(137, 11, '2022-03-27', 'SL-SML', 'Short Lino S-M-L', 100, 'stock-salida-productos.csv'),
(138, 11, '2022-03-27', 'SCCE-Nina', 'Short Chalis Color Entero Ni?a', 100, 'stock-salida-productos.csv'),
(139, 11, '2022-03-27', 'SCE-Nina', 'Short Chalis Estampado Ni?a', 100, 'stock-salida-productos.csv'),
(140, 11, '2022-03-27', 'SPCE-SML', 'Short Piel Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(141, 11, '2022-03-27', 'SPR-SML', 'Short Piel Rayas S-M-L', 100, 'stock-salida-productos.csv'),
(142, 11, '2022-03-27', 'SPM-SML', 'Short Piel Minipri S-M-L', 100, 'stock-salida-productos.csv'),
(143, 11, '2022-03-27', 'PE-SML', 'Pantalon Economico S-M-L', 100, 'stock-salida-productos.csv'),
(144, 11, '2022-03-27', 'PCV-SML', 'Pantalon Con Vena S-M-L', 100, 'stock-salida-productos.csv'),
(145, 11, '2022-03-27', 'PC-SML', 'Pantalon Catania S-M-L', 100, 'stock-salida-productos.csv'),
(146, 11, '2022-03-27', 'PSC-SML', 'Pantalon Ston Cuadros  S-M-L', 100, 'stock-salida-productos.csv'),
(147, 11, '2022-03-27', 'PL-SML', 'Pantalon Loma S-M-L', 100, 'stock-salida-productos.csv'),
(148, 11, '2022-03-27', 'PP-SML', 'Pantalon Palazo S-M-L', 100, 'stock-salida-productos.csv'),
(149, 11, '2022-03-27', 'PJ-SML', 'Pantalon Jogger S-M-L', 100, 'stock-salida-productos.csv'),
(150, 11, '2022-03-27', 'PPM-Adulto', 'Pantalon Piel Minipri Adulto', 100, 'stock-salida-productos.csv'),
(151, 11, '2022-03-27', 'PPM-Nina', 'Pantalon Piel Minipri Ni?a', 100, 'stock-salida-productos.csv'),
(152, 11, '2022-03-27', 'PPR-SML', 'Pantalon Piel Rayas S-M-L', 100, 'stock-salida-productos.csv'),
(153, 11, '2022-03-27', 'PPCE-SML', 'Pantalon Piel Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(154, 11, '2022-03-27', 'CE-SML', 'Chavo Economico S-M-L', 100, 'stock-salida-productos.csv'),
(155, 11, '2022-03-27', 'CPMN-468', 'Chavo Piel Minipri Ni?a 4-6-8', 100, 'stock-salida-productos.csv'),
(156, 11, '2022-03-27', 'CPMN-10121416', 'Chavo Piel Minipri Ni?a 10-12-14-16', 100, 'stock-salida-productos.csv'),
(157, 11, '2022-03-27', 'CPM-Adulto', 'Chavo Piel Minipri Adulto', 100, 'stock-salida-productos.csv'),
(158, 11, '2022-03-27', 'BC-SML', 'Bermuda Caballero S-M-L', 100, 'stock-salida-productos.csv'),
(159, 11, '2022-03-27', 'CL-SML', 'Chavo Lino S-M-L', 100, 'stock-salida-productos.csv'),
(160, 11, '2022-03-27', 'CPR-SML', 'Chavo Piel Rayas S-M-L', 100, 'stock-salida-productos.csv'),
(161, 11, '2022-03-27', 'CPCE-SML', 'Chavo Piel Color Entero S-M-L', 100, 'stock-salida-productos.csv'),
(162, 11, '2022-03-27', 'VPCE', 'Vestido Paty Corto Estampado', 100, 'stock-salida-productos.csv'),
(163, 11, '2022-03-27', 'VJCE', 'Vestido Jalapita Corto Estampado', 100, 'stock-salida-productos.csv'),
(164, 11, '2022-03-27', 'VCCCE', 'Vestido Con Copa Corto Estampado', 100, 'stock-salida-productos.csv'),
(165, 11, '2022-03-27', 'VECE', 'Vestido Ela Corto Estampado', 100, 'stock-salida-productos.csv'),
(166, 11, '2022-03-27', 'VCACE', 'Vestido Con Amarre Corto Estampado', 100, 'stock-salida-productos.csv'),
(167, 11, '2022-03-27', 'VETCE', 'Vestido Eliza Tira Corto Estampado', 100, 'stock-salida-productos.csv'),
(168, 11, '2022-03-27', 'VMACE', 'Vestido Manga Acero Corto Estampado', 100, 'stock-salida-productos.csv'),
(169, 11, '2022-03-27', 'VCMCE', 'Vestido Con Manga Corto Estampado', 100, 'stock-salida-productos.csv'),
(170, 11, '2022-03-27', 'VECCE', 'Vestido Ela Corto Color Entero', 100, 'stock-salida-productos.csv'),
(171, 11, '2022-03-27', 'VLCCE', 'Vestido Lazo al costado Corto Color Entero', 100, 'stock-salida-productos.csv'),
(172, 11, '2022-03-27', 'VMACCE', 'Vestido Manga Acero Corto Color Entero', 100, 'stock-salida-productos.csv'),
(173, 11, '2022-03-27', 'VCCCE', 'Vestido Con Copa Corto Estampado', 100, 'stock-salida-productos.csv'),
(174, 11, '2022-03-27', 'VAPCCE', 'Vestido Amarre en el Pecho Corto Color Entero', 100, 'stock-salida-productos.csv'),
(175, 11, '2022-03-27', 'ESCCE', 'Enterizo Susana Corto Color Entero', 100, 'stock-salida-productos.csv'),
(176, 11, '2022-03-27', 'ERCCE', 'Enterizo Rumbera Corto Color Entero', 100, 'stock-salida-productos.csv'),
(177, 11, '2022-03-27', 'VJE', 'Vestido Jalapita Estampado', 100, 'stock-salida-productos.csv'),
(178, 11, '2022-03-27', 'VYE', 'Vestido Yeni Estampado', 100, 'stock-salida-productos.csv'),
(179, 11, '2022-03-27', 'VETE', 'Vestido Eliza Tira Estampado', 100, 'stock-salida-productos.csv'),
(180, 11, '2022-03-27', 'VBE', 'Vestido Bolas Estampado', 100, 'stock-salida-productos.csv'),
(181, 11, '2022-03-27', 'VCE', 'Vestido Cruzado Estampado', 100, 'stock-salida-productos.csv'),
(182, 11, '2022-03-27', 'VEE', 'Vestido Ela Estampado', 100, 'stock-salida-productos.csv'),
(183, 11, '2022-03-27', 'VBLE', 'Vestido Betty Largo Estampado', 100, 'stock-salida-productos.csv'),
(184, 11, '2022-03-27', 'VELE', 'Vestido Estela Largo Estampado', 100, 'stock-salida-productos.csv'),
(185, 11, '2022-03-27', 'VHE', 'Vestido Hermana Estampado', 100, 'stock-salida-productos.csv'),
(186, 11, '2022-03-27', 'VACE', 'Vestido Argolla Color Entero', 100, 'stock-salida-productos.csv'),
(187, 11, '2022-03-27', 'VMACE', 'Vestido Manga Acero Corto Estampado', 100, 'stock-salida-productos.csv'),
(188, 11, '2022-03-27', 'VAPCE', 'Vestido Amarre en el Pecho Color Entero', 100, 'stock-salida-productos.csv'),
(189, 11, '2022-03-27', 'VSC', 'Vestido Ston Cuadros', 100, 'stock-salida-productos.csv'),
(190, 11, '2022-03-27', 'JCS-M', 'Jamper Cuadros S-M', 100, 'stock-salida-productos.csv'),
(191, 11, '2022-03-27', 'FS-SML', 'Falda Ston S-M-L', 100, 'stock-salida-productos.csv'),
(192, 11, '2022-03-27', 'FL-SML', 'Falda Loma S-M-L', 100, 'stock-salida-productos.csv'),
(193, 11, '2022-03-27', 'FSC-SML', 'Falda Short Cuadros S-M-L', 100, 'stock-salida-productos.csv'),
(194, 11, '2022-03-27', 'FCC-SML', 'Falda Corta Chalis S-M-L', 100, 'stock-salida-productos.csv'),
(195, 11, '2022-03-27', 'FC-SML', 'Faldon Chalis S-M-L', 100, 'stock-salida-productos.csv');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secuencia_envios_resboleta`
--

CREATE TABLE `secuencia_envios_resboleta` (
  `cod_secuencia` int(11) NOT NULL,
  `secuencia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `serie_documentos`
--

CREATE TABLE `serie_documentos` (
  `cod_serie` int(11) NOT NULL,
  `cod_personal` int(11) DEFAULT NULL,
  `codigo_compro` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serie` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_puntoventa` int(11) DEFAULT NULL,
  `num_inicial` int(11) DEFAULT NULL,
  `num_final` int(11) DEFAULT NULL,
  `num_actual` int(11) DEFAULT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `serie_documentos`
--

INSERT INTO `serie_documentos` (`cod_serie`, `cod_personal`, `codigo_compro`, `serie`, `cod_puntoventa`, `num_inicial`, `num_final`, `num_actual`, `estado`) VALUES
(1, 1, '01', 'FF01', 1, 0, NULL, 0, 'A'),
(2, 1, '03', 'BB01', 1, 0, NULL, 0, 'A'),
(3, 1, '07', 'FF01', 1, 0, NULL, 0, 'A'),
(4, 1, '07', 'BB01', 1, 0, NULL, 0, 'A'),
(5, 1, '100', 'NN01', 1, 0, NULL, 0, 'A'),
(6, 1, '09', 'T001', 1, 0, NULL, 0, 'A'),
(7, 1, '01', 'FF02', 11, 0, NULL, 1, 'A'),
(8, 1, '03', 'BB02', 11, 0, NULL, 4, 'A'),
(9, 1, '100', 'NN02', 11, 0, NULL, 1, 'A'),
(10, 1, '07', 'FF02', 11, 0, NULL, 0, 'A'),
(11, 1, '07', 'BB02', 11, 0, NULL, 0, 'A'),
(12, 1, '09', 'T002', 11, 0, NULL, 0, 'A'),
(13, 1, '01', 'FF03', 10, 0, NULL, 0, 'A'),
(14, 1, '03', 'BB03', 10, 0, NULL, 1, 'A'),
(15, 1, '100', 'NN03', 10, 0, NULL, 0, 'A'),
(16, 1, '07', 'FF03', 10, 0, NULL, 0, 'A'),
(17, 1, '07', 'BB03', 10, 0, NULL, 0, 'A'),
(18, 1, '09', 'T003', 10, 0, NULL, 0, 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stock_locales`
--

CREATE TABLE `stock_locales` (
  `cod_stocklocal` int(11) NOT NULL,
  `cod_puntoventa` int(11) DEFAULT NULL,
  `fecha_entrada` date DEFAULT NULL,
  `cod_producto` int(11) DEFAULT NULL,
  `codigo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre_producto` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stock_ingresado` int(11) DEFAULT NULL,
  `stock_minimo` int(11) DEFAULT NULL,
  `stock_actual` int(11) DEFAULT NULL,
  `total_ventas` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `stock_locales`
--

INSERT INTO `stock_locales` (`cod_stocklocal`, `cod_puntoventa`, `fecha_entrada`, `cod_producto`, `codigo`, `nombre_producto`, `stock_ingresado`, `stock_minimo`, `stock_actual`, `total_ventas`) VALUES
(1, 1, '2022-03-27', 1, 'SCCE-SML', 'Short Chalis Color Entero S-M-L', 300, NULL, 300, NULL),
(2, 1, '2022-03-27', 2, 'SCE-SML', 'Short Chalis Estampado S-M-L', 300, NULL, 300, NULL),
(3, 1, '2022-03-27', 3, 'SCCV-SML', 'Short Chalis Con Vena S-M-L', 300, NULL, 300, NULL),
(4, 1, '2022-03-27', 4, 'SSCL-SML', 'Short Ston Con Lazo S-M-L', 300, NULL, 300, NULL),
(5, 1, '2022-03-27', 5, 'SCS-SML', 'Short Cargo Ston S-M-L', 300, NULL, 300, NULL),
(6, 1, '2022-03-27', 6, 'SC-SML', 'Short Cuadros S-M-L', 300, NULL, 300, NULL),
(7, 1, '2022-03-27', 7, 'SL-SML', 'Short Lino S-M-L', 300, NULL, 300, NULL),
(8, 1, '2022-03-27', 8, 'SCCE-Nina', 'Short Chalis Color Entero Ni?a', 300, NULL, 300, NULL),
(9, 1, '2022-03-27', 9, 'SCE-Nina', 'Short Chalis Estampado Ni?a', 300, NULL, 300, NULL),
(10, 1, '2022-03-27', 10, 'SPCE-SML', 'Short Piel Color Entero S-M-L', 300, NULL, 300, NULL),
(11, 1, '2022-03-27', 11, 'SPR-SML', 'Short Piel Rayas S-M-L', 300, NULL, 300, NULL),
(12, 1, '2022-03-27', 12, 'SPM-SML', 'Short Piel Minipri S-M-L', 300, NULL, 300, NULL),
(13, 1, '2022-03-27', 13, 'PE-SML', 'Pantalon Economico S-M-L', 300, NULL, 300, NULL),
(14, 1, '2022-03-27', 14, 'PCV-SML', 'Pantalon Con Vena S-M-L', 300, NULL, 300, NULL),
(15, 1, '2022-03-27', 15, 'PC-SML', 'Pantalon Catania S-M-L', 300, NULL, 300, NULL),
(16, 1, '2022-03-27', 16, 'PSC-SML', 'Pantalon Ston Cuadros  S-M-L', 300, NULL, 300, NULL),
(17, 1, '2022-03-27', 17, 'PL-SML', 'Pantalon Loma S-M-L', 300, NULL, 300, NULL),
(18, 1, '2022-03-27', 18, 'PP-SML', 'Pantalon Palazo S-M-L', 300, NULL, 300, NULL),
(19, 1, '2022-03-27', 19, 'PJ-SML', 'Pantalon Jogger S-M-L', 300, NULL, 300, NULL),
(20, 1, '2022-03-27', 20, 'PPM-Adulto', 'Pantalon Piel Minipri Adulto', 300, NULL, 300, NULL),
(21, 1, '2022-03-27', 21, 'PPM-Nina', 'Pantalon Piel Minipri Ni?a', 300, NULL, 300, NULL),
(22, 1, '2022-03-27', 22, 'PPR-SML', 'Pantalon Piel Rayas S-M-L', 300, NULL, 300, NULL),
(23, 1, '2022-03-27', 23, 'PPCE-SML', 'Pantalon Piel Color Entero S-M-L', 300, NULL, 300, NULL),
(24, 1, '2022-03-27', 24, 'CE-SML', 'Chavo Economico S-M-L', 300, NULL, 300, NULL),
(25, 1, '2022-03-27', 25, 'CPMN-468', 'Chavo Piel Minipri Ni?a 4-6-8', 300, NULL, 300, NULL),
(26, 1, '2022-03-27', 26, 'CPMN-10121416', 'Chavo Piel Minipri Ni?a 10-12-14-16', 300, NULL, 300, NULL),
(27, 1, '2022-03-27', 27, 'CPM-Adulto', 'Chavo Piel Minipri Adulto', 300, NULL, 300, NULL),
(28, 1, '2022-03-27', 28, 'BC-SML', 'Bermuda Caballero S-M-L', 300, NULL, 300, NULL),
(29, 1, '2022-03-27', 29, 'CL-SML', 'Chavo Lino S-M-L', 300, NULL, 300, NULL),
(30, 1, '2022-03-27', 30, 'CPR-SML', 'Chavo Piel Rayas S-M-L', 300, NULL, 300, NULL),
(31, 1, '2022-03-27', 31, 'CPCE-SML', 'Chavo Piel Color Entero S-M-L', 300, NULL, 300, NULL),
(32, 1, '2022-03-27', 32, 'VPCE', 'Vestido Paty Corto Estampado', 300, NULL, 300, NULL),
(33, 1, '2022-03-27', 33, 'VJCE', 'Vestido Jalapita Corto Estampado', 300, NULL, 300, NULL),
(34, 1, '2022-03-27', 34, 'VCCCE', 'Vestido Con Copa Corto Estampado', 600, NULL, 600, NULL),
(35, 1, '2022-03-27', 35, 'VECE', 'Vestido Ela Corto Estampado', 300, NULL, 300, NULL),
(36, 1, '2022-03-27', 36, 'VCACE', 'Vestido Con Amarre Corto Estampado', 300, NULL, 300, NULL),
(37, 1, '2022-03-27', 37, 'VETCE', 'Vestido Eliza Tira Corto Estampado', 300, NULL, 300, NULL),
(38, 1, '2022-03-27', 38, 'VMACE', 'Vestido Manga Acero Corto Estampado', 600, NULL, 600, NULL),
(39, 1, '2022-03-27', 39, 'VCMCE', 'Vestido Con Manga Corto Estampado', 300, NULL, 300, NULL),
(40, 1, '2022-03-27', 40, 'VECCE', 'Vestido Ela Corto Color Entero', 300, NULL, 300, NULL),
(41, 1, '2022-03-27', 41, 'VLCCE', 'Vestido Lazo al costado Corto Color Entero', 300, NULL, 300, NULL),
(42, 1, '2022-03-27', 42, 'VMACCE', 'Vestido Manga Acero Corto Color Entero', 300, NULL, 300, NULL),
(43, 1, '2022-03-27', 43, 'VAPCCE', 'Vestido Amarre en el Pecho Corto Color Entero', 300, NULL, 300, NULL),
(44, 1, '2022-03-27', 44, 'ESCCE', 'Enterizo Susana Corto Color Entero', 300, NULL, 300, NULL),
(45, 1, '2022-03-27', 45, 'ERCCE', 'Enterizo Rumbera Corto Color Entero', 300, NULL, 300, NULL),
(46, 1, '2022-03-27', 46, 'VJE', 'Vestido Jalapita Estampado', 300, NULL, 300, NULL),
(47, 1, '2022-03-27', 47, 'VYE', 'Vestido Yeni Estampado', 300, NULL, 300, NULL),
(48, 1, '2022-03-27', 48, 'VETE', 'Vestido Eliza Tira Estampado', 300, NULL, 300, NULL),
(49, 1, '2022-03-27', 49, 'VBE', 'Vestido Bolas Estampado', 300, NULL, 300, NULL),
(50, 1, '2022-03-27', 50, 'VCE', 'Vestido Cruzado Estampado', 300, NULL, 300, NULL),
(51, 1, '2022-03-27', 51, 'VEE', 'Vestido Ela Estampado', 300, NULL, 300, NULL),
(52, 1, '2022-03-27', 52, 'VBLE', 'Vestido Betty Largo Estampado', 300, NULL, 300, NULL),
(53, 1, '2022-03-27', 53, 'VELE', 'Vestido Estela Largo Estampado', 300, NULL, 300, NULL),
(54, 1, '2022-03-27', 54, 'VHE', 'Vestido Hermana Estampado', 300, NULL, 300, NULL),
(55, 1, '2022-03-27', 55, 'VACE', 'Vestido Argolla Color Entero', 300, NULL, 300, NULL),
(56, 1, '2022-03-27', 56, 'VAPCE', 'Vestido Amarre en el Pecho Color Entero', 300, NULL, 300, NULL),
(57, 1, '2022-03-27', 57, 'VSC', 'Vestido Ston Cuadros', 300, NULL, 300, NULL),
(58, 1, '2022-03-27', 58, 'JCS-M', 'Jamper Cuadros S-M', 300, NULL, 300, NULL),
(59, 1, '2022-03-27', 59, 'FS-SML', 'Falda Ston S-M-L', 300, NULL, 300, NULL),
(60, 1, '2022-03-27', 60, 'FL-SML', 'Falda Loma S-M-L', 300, NULL, 300, NULL),
(61, 1, '2022-03-27', 61, 'FSC-SML', 'Falda Short Cuadros S-M-L', 300, NULL, 300, NULL),
(62, 1, '2022-03-27', 62, 'FCC-SML', 'Falda Corta Chalis S-M-L', 300, NULL, 300, NULL),
(63, 1, '2022-03-27', 63, 'FC-SML', 'Faldon Chalis S-M-L', 300, NULL, 300, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sub_modulos`
--

CREATE TABLE `sub_modulos` (
  `cod_submodulo` int(11) NOT NULL,
  `cod_modulo` int(11) DEFAULT NULL,
  `sub_modulo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enlace` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sub_modulos`
--

INSERT INTO `sub_modulos` (`cod_submodulo`, `cod_modulo`, `sub_modulo`, `enlace`, `estado`) VALUES
(1, 1, 'Datos de Empresa', 'datos-empresa.php', 'A'),
(2, 1, 'Tiendas/Locales', 'locales.php', 'A'),
(3, 1, 'Personal', 'personal.php', 'A'),
(4, 2, 'Apertura Caja', 'cajas.php', 'A'),
(5, 2, 'Crear Boletas/Facturas', 'ventas.php', 'A'),
(6, 2, 'Crear Notas de Crédito', 'notas-credito.php', 'A'),
(7, 2, 'Guias de Remisión', 'guias-de-remision.php', 'A'),
(8, 2, 'Lista de Ventas', 'lista-ventas.php', 'A'),
(9, 3, 'Facturas Electrónicas', 'facturas-electronicas.php', 'A'),
(10, 3, 'Boletas Electrónicas', 'boletas-electronicas.php', 'A'),
(11, 3, 'Resumen de Boletas', 'resumen-boletas.php', 'A'),
(12, 3, 'Enviar Guías de Remisión', 'enviar-guias-remision.ph', 'A'),
(13, 3, 'Reporte para Sunat', 'resumen-ventas-sunat.php', 'A'),
(14, 4, 'Categorias', 'categorias.php', 'A'),
(15, 4, 'Marcas', 'marcas.php', 'A'),
(16, 4, 'Productos', 'productos.php', 'A'),
(17, 5, 'Ingreso Productos', 'ingreso-productos.php', 'A'),
(18, 5, 'Salida Productos', 'salida-productos.php', 'A'),
(19, 5, 'Devoluciones', 'devoluciones.php', 'A'),
(20, 6, 'Modulos de Sistema', 'modulos.php', 'A'),
(21, 6, 'Tipos de Documento', 'tipos-documentos.php', 'A'),
(22, 6, 'Tipo Nota Credito', 'tipos-nota-credito.php', 'A'),
(23, 6, 'Series de Documento', 'series-documentos.php', 'A'),
(24, 6, 'Clientes', 'clientes.php', 'A'),
(25, 6, 'Cargos', 'cargos.php', 'A'),
(26, 7, 'Reportes Generales', 'reportes.php', 'A'),
(27, 8, 'Exportar Base de Datos', 'exportar-base-datos.php', 'A'),
(28, 8, 'Exportar Para Concat', 'exportar-para-concat.php', 'A'),
(29, 8, 'Exportar Syscont', 'exportar-para-syscont.php', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_documentos_identidad`
--

CREATE TABLE `tipos_documentos_identidad` (
  `cod_tipodoc` int(11) NOT NULL,
  `codigo_doc` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tipos_documentos_identidad`
--

INSERT INTO `tipos_documentos_identidad` (`cod_tipodoc`, `codigo_doc`, `descripcion`) VALUES
(1, '01', 'DNI'),
(2, '04', 'CARNET DE EXTRANJERIA'),
(3, '06', 'RUC'),
(4, '07', 'PASAPORTE'),
(5, '11', 'PART. DE NACIMIENTO'),
(6, '00', 'OTROS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_documento`
--

CREATE TABLE `tipo_documento` (
  `cod_tipo_compro` int(11) NOT NULL,
  `codigo_compro` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tipo_documento`
--

INSERT INTO `tipo_documento` (`cod_tipo_compro`, `codigo_compro`, `descripcion`, `estado`) VALUES
(1, '01', 'FACTURA', 'A'),
(2, '03', 'BOLETA DE VENTA', 'A'),
(3, '07', 'NOTA DE CREDITO', 'A'),
(4, '100', 'NOTA VENTAS', 'A'),
(5, '09', 'GUIA DE REMISIÓN REMITENTE', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tmp_salidastock`
--

CREATE TABLE `tmp_salidastock` (
  `id_tmp` int(11) NOT NULL,
  `cod_producto` int(11) DEFAULT NULL,
  `cantidad_tmp` int(11) DEFAULT NULL,
  `session_id` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tmp_ventas`
--

CREATE TABLE `tmp_ventas` (
  `id_tmp` int(11) NOT NULL,
  `cod_producto` int(11) DEFAULT NULL,
  `producto` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cantidad_tmp` int(11) DEFAULT NULL,
  `precio_tmp` double DEFAULT NULL,
  `session_id` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tienda` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `accesos_usuarios`
--
ALTER TABLE `accesos_usuarios`
  ADD PRIMARY KEY (`cod_acceso`);

--
-- Indices de la tabla `apertura_cajas`
--
ALTER TABLE `apertura_cajas`
  ADD PRIMARY KEY (`cod_apertura`);

--
-- Indices de la tabla `cargos_personal`
--
ALTER TABLE `cargos_personal`
  ADD PRIMARY KEY (`cod_cargo`);

--
-- Indices de la tabla `categoria_productos`
--
ALTER TABLE `categoria_productos`
  ADD PRIMARY KEY (`cod_categoria`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`cod_cliente`);

--
-- Indices de la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `id_factura` (`id_factura`);

--
-- Indices de la tabla `documentos_electronicos`
--
ALTER TABLE `documentos_electronicos`
  ADD PRIMARY KEY (`id_doc`);

--
-- Indices de la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`id_empresa`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`id_factura`),
  ADD KEY `serie` (`serie`),
  ADD KEY `num_comprobante` (`num_comprobante`),
  ADD KEY `razon_social` (`razon_social`);

--
-- Indices de la tabla `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ingreso_stock`
--
ALTER TABLE `ingreso_stock`
  ADD PRIMARY KEY (`cod_ingreso`);

--
-- Indices de la tabla `marcas`
--
ALTER TABLE `marcas`
  ADD PRIMARY KEY (`cod_marca`);

--
-- Indices de la tabla `modulos`
--
ALTER TABLE `modulos`
  ADD PRIMARY KEY (`cod_modulo`);

--
-- Indices de la tabla `motivo_nota_credito`
--
ALTER TABLE `motivo_nota_credito`
  ADD PRIMARY KEY (`cod_motivo`);

--
-- Indices de la tabla `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`cod_personal`),
  ADD KEY `num_documento` (`num_documento`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`cod_producto`);

--
-- Indices de la tabla `puntos_ventas`
--
ALTER TABLE `puntos_ventas`
  ADD PRIMARY KEY (`cod_puntoventa`);

--
-- Indices de la tabla `salida_stock`
--
ALTER TABLE `salida_stock`
  ADD PRIMARY KEY (`cod_salidastock`);

--
-- Indices de la tabla `secuencia_envios_resboleta`
--
ALTER TABLE `secuencia_envios_resboleta`
  ADD PRIMARY KEY (`cod_secuencia`);

--
-- Indices de la tabla `serie_documentos`
--
ALTER TABLE `serie_documentos`
  ADD PRIMARY KEY (`cod_serie`);

--
-- Indices de la tabla `stock_locales`
--
ALTER TABLE `stock_locales`
  ADD PRIMARY KEY (`cod_stocklocal`);

--
-- Indices de la tabla `sub_modulos`
--
ALTER TABLE `sub_modulos`
  ADD PRIMARY KEY (`cod_submodulo`);

--
-- Indices de la tabla `tipos_documentos_identidad`
--
ALTER TABLE `tipos_documentos_identidad`
  ADD PRIMARY KEY (`cod_tipodoc`);

--
-- Indices de la tabla `tipo_documento`
--
ALTER TABLE `tipo_documento`
  ADD PRIMARY KEY (`cod_tipo_compro`);

--
-- Indices de la tabla `tmp_salidastock`
--
ALTER TABLE `tmp_salidastock`
  ADD PRIMARY KEY (`id_tmp`);

--
-- Indices de la tabla `tmp_ventas`
--
ALTER TABLE `tmp_ventas`
  ADD PRIMARY KEY (`id_tmp`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `accesos_usuarios`
--
ALTER TABLE `accesos_usuarios`
  MODIFY `cod_acceso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;

--
-- AUTO_INCREMENT de la tabla `apertura_cajas`
--
ALTER TABLE `apertura_cajas`
  MODIFY `cod_apertura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `cargos_personal`
--
ALTER TABLE `cargos_personal`
  MODIFY `cod_cargo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `categoria_productos`
--
ALTER TABLE `categoria_productos`
  MODIFY `cod_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `cod_cliente` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `documentos_electronicos`
--
ALTER TABLE `documentos_electronicos`
  MODIFY `id_doc` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `empresa`
--
ALTER TABLE `empresa`
  MODIFY `id_empresa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `id_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `ingreso_stock`
--
ALTER TABLE `ingreso_stock`
  MODIFY `cod_ingreso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT de la tabla `marcas`
--
ALTER TABLE `marcas`
  MODIFY `cod_marca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `modulos`
--
ALTER TABLE `modulos`
  MODIFY `cod_modulo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `motivo_nota_credito`
--
ALTER TABLE `motivo_nota_credito`
  MODIFY `cod_motivo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `personal`
--
ALTER TABLE `personal`
  MODIFY `cod_personal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `cod_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT de la tabla `puntos_ventas`
--
ALTER TABLE `puntos_ventas`
  MODIFY `cod_puntoventa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `salida_stock`
--
ALTER TABLE `salida_stock`
  MODIFY `cod_salidastock` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=196;

--
-- AUTO_INCREMENT de la tabla `secuencia_envios_resboleta`
--
ALTER TABLE `secuencia_envios_resboleta`
  MODIFY `cod_secuencia` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `serie_documentos`
--
ALTER TABLE `serie_documentos`
  MODIFY `cod_serie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `stock_locales`
--
ALTER TABLE `stock_locales`
  MODIFY `cod_stocklocal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT de la tabla `sub_modulos`
--
ALTER TABLE `sub_modulos`
  MODIFY `cod_submodulo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `tipos_documentos_identidad`
--
ALTER TABLE `tipos_documentos_identidad`
  MODIFY `cod_tipodoc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `tipo_documento`
--
ALTER TABLE `tipo_documento`
  MODIFY `cod_tipo_compro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `tmp_salidastock`
--
ALTER TABLE `tmp_salidastock`
  MODIFY `id_tmp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `tmp_ventas`
--
ALTER TABLE `tmp_ventas`
  MODIFY `id_tmp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
