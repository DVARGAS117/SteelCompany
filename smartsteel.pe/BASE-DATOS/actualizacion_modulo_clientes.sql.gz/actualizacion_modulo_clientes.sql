/* *************************************************************************************************************************************************************************** */
-- 1.
UPDATE personal SET usuario = 'd033e22ae348aeb5660fc2140aec35850c4da997' AND clave = '40bd001563085fc35165329ea1ff5c5ecbdbbeef' WHERE cod_personal = 1;

/* *************************************************************************************************************************************************************************** */
-- 2.
ALTER TABLE `roque_smartsteel`.`tipo_giro_negocios` 
ADD COLUMN `estado` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'A' AFTER `nombre_giro`,
ADD COLUMN `fecha_creacion` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0) AFTER `estado`,
ADD COLUMN `fecha_actualizacion` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP AFTER `fecha_creacion`;

/* *************************************************************************************************************************************************************************** */
-- 3.
ALTER TABLE `roque_smartsteel`.`tipos_documentos_identidad` 
ADD COLUMN `estado` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'A' AFTER `descripcion`,
ADD COLUMN `fecha_creacion` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0) AFTER `estado`,
ADD COLUMN `fecha_actualizacion` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP AFTER `fecha_creacion`;

/* *************************************************************************************************************************************************************************** */
-- 4.
ALTER TABLE `roque_smartsteel`.`clientes` 
MODIFY COLUMN `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP AFTER `cod_cliente`,
MODIFY COLUMN `fecha_actualizacion` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP AFTER `fecha_creacion`;

/* *************************************************************************************************************************************************************************** */
-- 5.
INSERT INTO sub_modulos (cod_submodulo, cod_modulo, sub_modulo, enlace, estado) VALUES (36, 1, 'Sedes por Cliente', 'clientes-sedes.php', 'A');
INSERT INTO sub_modulos (cod_submodulo, cod_modulo, sub_modulo, enlace, estado) VALUES (37, 1, 'Contactos por Sede', 'clientes-sedes-contactos.php', 'A');

/* *************************************************************************************************************************************************************************** */
-- 6.
INSERT INTO accesos_usuarios (cod_personal, cod_modulo, cod_submodulo, modulo, insertar, editar, eliminar, consultar) VALUES (1, 1, 36, 'Sedes por Cliente', 'SI', 'SI', 'SI', 'SI');
INSERT INTO accesos_usuarios (cod_personal, cod_modulo, cod_submodulo, modulo, insertar, editar, eliminar, consultar) VALUES (1, 1, 37, 'Contactos por Sede', 'SI', 'SI', 'SI', 'SI');
INSERT INTO accesos_usuarios (cod_personal, cod_modulo, cod_submodulo, modulo, insertar, editar, eliminar, consultar) VALUES (8, 1, 36, 'Sedes por Cliente', 'SI', 'SI', 'SI', 'SI');
INSERT INTO accesos_usuarios (cod_personal, cod_modulo, cod_submodulo, modulo, insertar, editar, eliminar, consultar) VALUES (8, 1, 37, 'Contactos por Sede', 'SI', 'SI', 'SI', 'SI');

/* *************************************************************************************************************************************************************************** */
-- 7.
CREATE TABLE `roque_smartsteel`.`clientes_sedes`  (
  `cod_sede` int NOT NULL AUTO_INCREMENT,
  `cod_cliente` int NULL DEFAULT NULL,
  `id_tipo_direccion` int NULL DEFAULT NULL,
  `direccion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `referencia` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `IdDepartamento` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `IdProvincia` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `IdDistrito` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `estado` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'A',
  `fecha_creacion` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `fecha_actualizacion` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`cod_sede`)
) ENGINE = MyISAM CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

/* *************************************************************************************************************************************************************************** */
-- 8.
ALTER TABLE `roque_smartsteel`.`tipo_direccion` 
ADD COLUMN `estado` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'A' AFTER `tipo_direccion`,
ADD COLUMN `fecha_creacion` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0) AFTER `estado`,
ADD COLUMN `fecha_actualizacion` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0) AFTER `fecha_creacion`;

/* *************************************************************************************************************************************************************************** */
-- 9.
ALTER TABLE `roque_smartsteel`.`ubigeo_departamentos` 
MODIFY COLUMN `id` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL FIRST,
MODIFY COLUMN `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL AFTER `id`;

ALTER TABLE `roque_smartsteel`.`ubigeo_provincias` 
MODIFY COLUMN `id` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL FIRST,
MODIFY COLUMN `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL AFTER `id`,
MODIFY COLUMN `department_id` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL AFTER `name`;

ALTER TABLE `roque_smartsteel`.`ubigeo_distritos` 
MODIFY COLUMN `id` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL FIRST,
MODIFY COLUMN `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL AFTER `id`,
MODIFY COLUMN `province_id` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL AFTER `name`,
MODIFY COLUMN `department_id` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL AFTER `province_id`;

ALTER TABLE `roque_smartsteel`.`empresa` 
MODIFY COLUMN `Departamento` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL AFTER `direccion`,
MODIFY COLUMN `Provincia` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL AFTER `Departamento`,
MODIFY COLUMN `Distrito` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL AFTER `Provincia`;

/* *************************************************************************************************************************************************************************** */
-- 10.
CREATE TABLE `roque_smartsteel`.`clientes_sedes_contactos`  (
  `cod_contacto` int NOT NULL AUTO_INCREMENT,
  `cod_sede` int NULL DEFAULT NULL,
  `id_tipo_contacto` int NULL DEFAULT NULL,
  `persona_contacto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `telefono_1` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `telefono_2` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `estado` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'A',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cod_contacto`)
) ENGINE = MyISAM CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

/* *************************************************************************************************************************************************************************** */
-- 11.
ALTER TABLE `roque_smartsteel`.`tipo_contactos` 
ADD COLUMN `estado` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'A' AFTER `tipo_contacto`,
ADD COLUMN `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP AFTER `estado`,
ADD COLUMN `fecha_actualizacion` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP AFTER `fecha_creacion`;
-- https://remixicon.com/